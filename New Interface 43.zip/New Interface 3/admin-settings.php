<?php
/**
 * Add this to your main plugin file (recenzuju-feedback-form.php)
 */

// Register settings page
add_action('admin_menu', 'recenzuju_register_settings_page');
add_action('admin_init', 'recenzuju_register_settings');

function recenzuju_register_settings_page() {
    add_menu_page(
        'Recenzuju Settings',           // Page title
        'Recenzuju',                    // Menu title
        'manage_options',               // Capability
        'recenzuju-settings',           // Menu slug
        'recenzuju_render_settings_page', // Callback function
        'dashicons-star-filled',        // Icon
        30                              // Position
    );

    add_submenu_page(
        'recenzuju-settings',           // Parent slug
        'Dashboard',                    // Page title
        'Dashboard',                    // Menu title
        'manage_options',               // Capability
        'recenzuju-dashboard',          // Menu slug
        'recenzuju_render_dashboard'    // Callback function
    );

    add_submenu_page(
        'recenzuju-settings',           // Parent slug
        'Analytics',                    // Page title
        'Analytics',                    // Menu title
        'manage_options',               // Capability
        'recenzuju-analytics',          // Menu slug
        'recenzuju_render_analytics'    // Callback function
    );
}

function recenzuju_register_settings() {
    // API Settings Section
    add_settings_section(
        'recenzuju_api_settings',
        'API Configuration',
        'recenzuju_api_settings_callback',
        'recenzuju-settings'
    );

    // Database Settings Section
    add_settings_section(
        'recenzuju_db_settings',
        'Database Configuration',
        'recenzuju_db_settings_callback',
        'recenzuju-settings'
    );

    // System Settings Section
    add_settings_section(
        'recenzuju_system_settings',
        'System Configuration',
        'recenzuju_system_settings_callback',
        'recenzuju-settings'
    );

    // Register API key settings
    register_setting('recenzuju-settings-group', 'recenzuju_airtable_api_key', [
        'sanitize_callback' => 'sanitize_text_field',
        'default' => ''
    ]);
    register_setting('recenzuju-settings-group', 'recenzuju_airtable_base_id', [
        'sanitize_callback' => 'sanitize_text_field',
        'default' => ''
    ]);
    register_setting('recenzuju-settings-group', 'recenzuju_airtable_table_id', [
        'sanitize_callback' => 'sanitize_text_field',
        'default' => ''
    ]);
    register_setting('recenzuju-settings-group', 'recenzuju_openai_api_key', [
        'sanitize_callback' => 'sanitize_text_field',
        'default' => ''
    ]);

    // Register database settings
    register_setting('recenzuju-settings-group', 'recenzuju_db_host', [
        'sanitize_callback' => 'sanitize_text_field',
        'default' => ''
    ]);
    register_setting('recenzuju-settings-group', 'recenzuju_db_user', [
        'sanitize_callback' => 'sanitize_text_field',
        'default' => ''
    ]);
    register_setting('recenzuju-settings-group', 'recenzuju_db_pass', [
        'sanitize_callback' => 'sanitize_text_field',
        'default' => ''
    ]);
    register_setting('recenzuju-settings-group', 'recenzuju_db_name', [
        'sanitize_callback' => 'sanitize_text_field',
        'default' => ''
    ]);

    // Register system settings
    register_setting('recenzuju-settings-group', 'recenzuju_daily_review_limit', [
        'sanitize_callback' => 'intval',
        'default' => 3
    ]);
    register_setting('recenzuju-settings-group', 'recenzuju_assignment_timeout', [
        'sanitize_callback' => 'intval',
        'default' => 30
    ]);
    register_setting('recenzuju-settings-group', 'recenzuju_enable_debug_mode', [
        'sanitize_callback' => 'boolval',
        'default' => false
    ]);

    // Add settings fields for API keys
    add_settings_field(
        'recenzuju_airtable_api_key',
        'Airtable API Key',
        'recenzuju_text_field_callback',
        'recenzuju-settings',
        'recenzuju_api_settings',
        ['label_for' => 'recenzuju_airtable_api_key']
    );
    add_settings_field(
        'recenzuju_airtable_base_id',
        'Airtable Base ID',
        'recenzuju_text_field_callback',
        'recenzuju-settings',
        'recenzuju_api_settings',
        ['label_for' => 'recenzuju_airtable_base_id']
    );
    add_settings_field(
        'recenzuju_airtable_table_id',
        'Airtable Table ID',
        'recenzuju_text_field_callback',
        'recenzuju-settings',
        'recenzuju_api_settings',
        ['label_for' => 'recenzuju_airtable_table_id']
    );
    add_settings_field(
        'recenzuju_openai_api_key',
        'OpenAI API Key',
        'recenzuju_text_field_callback',
        'recenzuju-settings',
        'recenzuju_api_settings',
        ['label_for' => 'recenzuju_openai_api_key']
    );

    // Add settings fields for database
    add_settings_field(
        'recenzuju_db_host',
        'Database Host',
        'recenzuju_text_field_callback',
        'recenzuju-settings',
        'recenzuju_db_settings',
        ['label_for' => 'recenzuju_db_host']
    );
    add_settings_field(
        'recenzuju_db_user',
        'Database Username',
        'recenzuju_text_field_callback',
        'recenzuju-settings',
        'recenzuju_db_settings',
        ['label_for' => 'recenzuju_db_user']
    );
    add_settings_field(
        'recenzuju_db_pass',
        'Database Password',
        'recenzuju_password_field_callback',
        'recenzuju-settings',
        'recenzuju_db_settings',
        ['label_for' => 'recenzuju_db_pass']
    );
    add_settings_field(
        'recenzuju_db_name',
        'Database Name',
        'recenzuju_text_field_callback',
        'recenzuju-settings',
        'recenzuju_db_settings',
        ['label_for' => 'recenzuju_db_name']
    );

    // Add settings fields for system
    add_settings_field(
        'recenzuju_daily_review_limit',
        'Daily Review Limit',
        'recenzuju_number_field_callback',
        'recenzuju-settings',
        'recenzuju_system_settings',
        [
            'label_for' => 'recenzuju_daily_review_limit',
            'min' => 1,
            'max' => 10,
            'step' => 1
        ]
    );
    add_settings_field(
        'recenzuju_assignment_timeout',
        'Assignment Timeout (minutes)',
        'recenzuju_number_field_callback',
        'recenzuju-settings',
        'recenzuju_system_settings',
        [
            'label_for' => 'recenzuju_assignment_timeout',
            'min' => 5,
            'max' => 60,
            'step' => 5
        ]
    );
    add_settings_field(
        'recenzuju_enable_debug_mode',
        'Enable Debug Mode',
        'recenzuju_checkbox_field_callback',
        'recenzuju-settings',
        'recenzuju_system_settings',
        ['label_for' => 'recenzuju_enable_debug_mode']
    );
}

// Section callbacks
function recenzuju_api_settings_callback() {
    echo '<p>Configure your external API credentials. These are used to connect to Airtable and OpenAI services.</p>';
}

function recenzuju_db_settings_callback() {
    echo '<p>Configure your database connection settings. These will be used instead of hardcoded values.</p>';
}

function recenzuju_system_settings_callback() {
    echo '<p>Configure system behavior and limits.</p>';
}

// Field callbacks
function recenzuju_text_field_callback($args) {
    $option_name = $args['label_for'];
    $value = get_option($option_name);
    echo '<input type="text" id="' . esc_attr($option_name) . '" name="' . esc_attr($option_name) . '" value="' . esc_attr($value) . '" class="regular-text">';
}

function recenzuju_password_field_callback($args) {
    $option_name = $args['label_for'];
    $value = get_option($option_name);
    echo '<input type="password" id="' . esc_attr($option_name) . '" name="' . esc_attr($option_name) . '" value="' . esc_attr($value) . '" class="regular-text">';
}

function recenzuju_number_field_callback($args) {
    $option_name = $args['label_for'];
    $value = get_option($option_name);
    $min = isset($args['min']) ? $args['min'] : 0;
    $max = isset($args['max']) ? $args['max'] : 100;
    $step = isset($args['step']) ? $args['step'] : 1;
    
    echo '<input type="number" id="' . esc_attr($option_name) . '" name="' . esc_attr($option_name) . '" value="' . esc_attr($value) . '" 
        min="' . esc_attr($min) . '" max="' . esc_attr($max) . '" step="' . esc_attr($step) . '" class="small-text">';
}

function recenzuju_checkbox_field_callback($args) {
    $option_name = $args['label_for'];
    $value = get_option($option_name);
    echo '<input type="checkbox" id="' . esc_attr($option_name) . '" name="' . esc_attr($option_name) . '" value="1" ' . checked(1, $value, false) . '>';
}

// Render the settings page
function recenzuju_render_settings_page() {
    if (!current_user_can('manage_options')) {
        return;
    }
    
    // Check if settings were saved
    if (isset($_GET['settings-updated'])) {
        add_settings_error('recenzuju_messages', 'recenzuju_message', 'Settings Saved', 'updated');
    }
    
    // Show any error messages
    settings_errors('recenzuju_messages');
    ?>
    <div class="wrap">
        <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
        
        <form action="options.php" method="post">
            <?php
            settings_fields('recenzuju-settings-group');
            do_settings_sections('recenzuju-settings');
            submit_button('Save Settings');
            ?>
        </form>
        
        <div class="card" style="max-width: 800px; margin-top: 20px; padding: 20px;">
            <h2>Test Connection</h2>
            <p>Test your database and API connections to ensure everything is configured correctly.</p>
            <button id="test-db-connection" class="button button-secondary">Test Database Connection</button>
            <button id="test-airtable-connection" class="button button-secondary">Test Airtable Connection</button>
            <button id="test-openai-connection" class="button button-secondary">Test OpenAI Connection</button>
            
            <div id="connection-results" style="margin-top: 15px; padding: 10px; background: #f8f8f8; border-left: 4px solid #bbb; display: none;"></div>
        </div>
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        $('#test-db-connection').click(function(e) {
            e.preventDefault();
            $('#connection-results').html('<p>Testing database connection...</p>').show();
            
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'recenzuju_test_db_connection'
                },
                success: function(response) {
                    if (response.success) {
                        $('#connection-results').html('<p style="color: green;">✓ Database connection successful!</p>');
                    } else {
                        $('#connection-results').html('<p style="color: red;">✗ Database connection failed: ' + response.data + '</p>');
                    }
                },
                error: function() {
                    $('#connection-results').html('<p style="color: red;">✗ AJAX request failed.</p>');
                }
            });
        });
        
        $('#test-airtable-connection').click(function(e) {
            e.preventDefault();
            $('#connection-results').html('<p>Testing Airtable connection...</p>').show();
            
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'recenzuju_test_airtable_connection'
                },
                success: function(response) {
                    if (response.success) {
                        $('#connection-results').html('<p style="color: green;">✓ Airtable connection successful!</p>');
                    } else {
                        $('#connection-results').html('<p style="color: red;">✗ Airtable connection failed: ' + response.data + '</p>');
                    }
                },
                error: function() {
                    $('#connection-results').html('<p style="color: red;">✗ AJAX request failed.</p>');
                }
            });
        });
        
        $('#test-openai-connection').click(function(e) {
            e.preventDefault();
            $('#connection-results').html('<p>Testing OpenAI connection...</p>').show();
            
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'recenzuju_test_openai_connection'
                },
                success: function(response) {
                    if (response.success) {
                        $('#connection-results').html('<p style="color: green;">✓ OpenAI connection successful!</p>');
                    } else {
                        $('#connection-results').html('<p style="color: red;">✗ OpenAI connection failed: ' + response.data + '</p>');
                    }
                },
                error: function() {
                    $('#connection-results').html('<p style="color: red;">✗ AJAX request failed.</p>');
                }
            });
        });
    });
    </script>
    <?php
}

// Render the dashboard page
function recenzuju_render_dashboard() {
    if (!current_user_can('manage_options')) {
        return;
    }
    ?>
    <div class="wrap">
        <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
        
        <div class="dashboard-widgets" style="display: flex; flex-wrap: wrap; gap: 20px;">
            <!-- Statistics Widget -->
            <div class="card" style="width: calc(50% - 10px); min-width: 400px; padding: 20px;">
                <h2>System Statistics</h2>
                <?php
                try {
                    $conn = getConnection();
                    
                    // Assignment statistics
                    $stmt = $conn->query("
                        SELECT 
                            COUNT(*) as total,
                            SUM(CASE WHEN status = 'unassigned' THEN 1 ELSE 0 END) as unassigned,
                            SUM(CASE WHEN status = 'assigned' THEN 1 ELSE 0 END) as assigned,
                            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed
                        FROM assignments
                    ");
                    $assignments = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    // Review statistics
                    $stmt = $conn->query("
                        SELECT 
                            COUNT(*) as total,
                            COUNT(DISTINCT user_login) as unique_users,
                            MAX(review_date) as latest_review
                        FROM reviews
                    ");
                    $reviews = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    // Reviews today
                    $stmt = $conn->query("
                        SELECT COUNT(*) as today_count
                        FROM reviews
                        WHERE review_date >= CURDATE()
                    ");
                    $today = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    echo '<h3>Assignments</h3>';
                    echo '<ul>';
                    echo '<li><strong>Total:</strong> ' . $assignments['total'] . '</li>';
                    echo '<li><strong>Unassigned:</strong> ' . $assignments['unassigned'] . '</li>';
                    echo '<li><strong>In Progress:</strong> ' . $assignments['assigned'] . '</li>';
                    echo '<li><strong>Completed:</strong> ' . $assignments['completed'] . '</li>';
                    echo '</ul>';
                    
                    echo '<h3>Reviews</h3>';
                    echo '<ul>';
                    echo '<li><strong>Total Reviews:</strong> ' . $reviews['total'] . '</li>';
                    echo '<li><strong>Unique Reviewers:</strong> ' . $reviews['unique_users'] . '</li>';
                    echo '<li><strong>Today\'s Reviews:</strong> ' . $today['today_count'] . '</li>';
                    echo '<li><strong>Latest Review:</strong> ' . $reviews['latest_review'] . '</li>';
                    echo '</ul>';
                    
                } catch (Exception $e) {
                    echo '<div class="notice notice-error"><p>Error retrieving statistics: ' . esc_html($e->getMessage()) . '</p></div>';
                }
                ?>
            </div>
            
            <!-- Recent Activity Widget -->
            <div class="card" style="width: calc(50% - 10px); min-width: 400px; padding: 20px;">
                <h2>Recent Reviews</h2>
                <?php
                try {
                    $conn = getConnection();
                    
                    $stmt = $conn->query("
                        SELECT user_login, review_date, google_maps_url, LEFT(review_text, 100) as preview
                        FROM reviews
                        ORDER BY review_date DESC
                        LIMIT 10
                    ");
                    $recent_reviews = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    if (count($recent_reviews) > 0) {
                        echo '<table class="wp-list-table widefat fixed striped">';
                        echo '<thead><tr><th>User</th><th>Date</th><th>Content</th></tr></thead>';
                        echo '<tbody>';
                        
                        foreach ($recent_reviews as $review) {
                            echo '<tr>';
                            echo '<td>' . esc_html($review['user_login']) . '</td>';
                            echo '<td>' . esc_html($review['review_date']) . '</td>';
                            echo '<td>';
                            echo '<strong>URL:</strong> <a href="' . esc_url($review['google_maps_url']) . '" target="_blank">View</a><br>';
                            echo '<strong>Preview:</strong> ' . esc_html($review['preview']) . '...';
                            echo '</td>';
                            echo '</tr>';
                        }
                        
                        echo '</tbody></table>';
                    } else {
                        echo '<p>No recent reviews found.</p>';
                    }
                    
                } catch (Exception $e) {
                    echo '<div class="notice notice-error"><p>Error retrieving recent reviews: ' . esc_html($e->getMessage()) . '</p></div>';
                }
                ?>
            </div>
            
            <!-- System Health Widget -->
            <div class="card" style="width: calc(50% - 10px); min-width: 400px; padding: 20px;">
                <h2>System Health</h2>
                <?php
                // Check database connection
                $db_connected = false;
                try {
                    $conn = getConnection();
                    $stmt = $conn->query("SELECT 1");
                    $db_connected = ($stmt !== false);
                } catch (Exception $e) {
                    $db_error = $e->getMessage();
                }
                
                // Check Airtable API key
                $airtable_key = get_option('recenzuju_airtable_api_key');
                $airtable_configured = !empty($airtable_key);
                
                // Check OpenAI API key
                $openai_key = get_option('recenzuju_openai_api_key');
                $openai_configured = !empty($openai_key);
                
                echo '<ul class="health-checks">';
                
                // Database connection
                echo '<li style="margin-bottom: 10px;">';
                if ($db_connected) {
                    echo '<span style="color: green; font-weight: bold;">✓</span> Database connection is working';
                } else {
                    echo '<span style="color: red; font-weight: bold;">✗</span> Database connection failed: ' . esc_html($db_error ?? 'Unknown error');
                }
                echo '</li>';
                
                // Airtable configuration
                echo '<li style="margin-bottom: 10px;">';
                if ($airtable_configured) {
                    echo '<span style="color: green; font-weight: bold;">✓</span> Airtable API key is configured';
                } else {
                    echo '<span style="color: red; font-weight: bold;">✗</span> Airtable API key is not configured';
                }
                echo '</li>';
                
                // OpenAI configuration
                echo '<li style="margin-bottom: 10px;">';
                if ($openai_configured) {
                    echo '<span style="color: green; font-weight: bold;">✓</span> OpenAI API key is configured';
                } else {
                    echo '<span style="color: orange; font-weight: bold;">!</span> OpenAI API key is not configured (fallback reviews will be used)';
                }
                echo '</li>';
                
                // Tables existence
                if ($db_connected) {
                    try {
                        $reviews_exists = $conn->query("SHOW TABLES LIKE 'reviews'")->rowCount() > 0;
                        $assignments_exists = $conn->query("SHOW TABLES LIKE 'assignments'")->rowCount() > 0;
                        
                        echo '<li style="margin-bottom: 10px;">';
                        if ($reviews_exists) {
                            echo '<span style="color: green; font-weight: bold;">✓</span> Reviews table exists';
                        } else {
                            echo '<span style="color: red; font-weight: bold;">✗</span> Reviews table does not exist';
                        }
                        echo '</li>';
                        
                        echo '<li style="margin-bottom: 10px;">';
                        if ($assignments_exists) {
                            echo '<span style="color: green; font-weight: bold;">✓</span> Assignments table exists';
                        } else {
                            echo '<span style="color: red; font-weight: bold;">✗</span> Assignments table does not exist';
                        }
                        echo '</li>';
                    } catch (Exception $e) {
                        echo '<li><span style="color: red; font-weight: bold;">✗</span> Error checking tables: ' . esc_html($e->getMessage()) . '</li>';
                    }
                }
                
                echo '</ul>';
                
                echo '<p><button id="run-system-check" class="button button-primary">Run System Check</button></p>';
                echo '<div id="system-check-results" style="display: none; margin-top: 15px; padding: 10px; background: #f8f8f8; border-left: 4px solid #bbb;"></div>';
                ?>
                
                <script>
                jQuery(document).ready(function($) {
                    $('#run-system-check').click(function(e) {
                        e.preventDefault();
                        $('#system-check-results').html('<p>Running system check...</p>').show();
                        
                        $.ajax({
                            url: ajaxurl,
                            type: 'POST',
                            data: {
                                action: 'recenzuju_run_system_check'
                            },
                            success: function(response) {
                                if (response.success) {
                                    $('#system-check-results').html(response.data);
                                } else {
                                    $('#system-check-results').html('<p style="color: red;">Error: ' + response.data + '</p>');
                                }
                            },
                            error: function() {
                                $('#system-check-results').html('<p style="color: red;">AJAX request failed.</p>');
                            }
                        });
                    });
                });
                </script>
            </div>
            
            <!-- Tools Widget -->
            <div class="card" style="width: calc(50% - 10px); min-width: 400px; padding: 20px;">
                <h2>Maintenance Tools</h2>
                <p>Use these tools with caution. They perform database operations that may affect your data.</p>
                
                <div class="tools-grid" style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-top: 20px;">
                    <div class="tool-card" style="padding: 15px; background: #f9f9f9; border-radius: 4px;">
                        <h3>Release Orphaned Assignments</h3>
                        <p>Release assignments that have been stuck in the 'assigned' state for too long.</p>
                        <button id="release-orphaned" class="button button-secondary">Release Orphaned</button>
                    </div>
                    
                    <div class="tool-card" style="padding: 15px; background: #f9f9f9; border-radius: 4px;">
                        <h3>Reset Review Limits</h3>
                        <p>Reset review counts for a specific user or all users.</p>
                        <input type="text" id="reset-user-login" placeholder="Username (leave empty for all)" style="width: 100%; margin-bottom: 10px;">
                        <button id="reset-review-limits" class="button button-secondary">Reset Limits</button>
                    </div>
                    
                    <div class="tool-card" style="padding: 15px; background: #f9f9f9; border-radius: 4px;">
                        <h3>Check Tables</h3>
                        <p>Verify and repair database tables if needed.</p>
                        <button id="check-tables" class="button button-secondary">Check Tables</button>
                    </div>
                    
                    <div class="tool-card" style="padding: 15px; background: #f9f9f9; border-radius: 4px;">
                        <h3>Export Reviews</h3>
                        <p>Export all reviews to a CSV file.</p>
                        <button id="export-reviews" class="button button-secondary">Export Reviews</button>
                    </div>
                </div>
                
                <div id="tool-results" style="margin-top: 20px; padding: 15px; background: #f8f8f8; border-left: 4px solid #bbb; display: none;"></div>
                
                <script>
                jQuery(document).ready(function($) {
                    $('#release-orphaned').click(function(e) {
                        e.preventDefault();
                        if (confirm('Are you sure you want to release orphaned assignments?')) {
                            $('#tool-results').html('<p>Releasing orphaned assignments...</p>').show();
                            
                            $.ajax({
                                url: ajaxurl,
                                type: 'POST',
                                data: {
                                    action: 'recenzuju_release_orphaned'
                                },
                                success: function(response) {
                                    if (response.success) {
                                        $('#tool-results').html('<p style="color: green;">✓ ' + response.data + '</p>');
                                    } else {
                                        $('#tool-results').html('<p style="color: red;">✗ ' + response.data + '</p>');
                                    }
                                },
                                error: function() {
                                    $('#tool-results').html('<p style="color: red;">✗ AJAX request failed.</p>');
                                }
                            });
                        }
                    });
                    
                    $('#reset-review-limits').click(function(e) {
                        e.preventDefault();
                        const username = $('#reset-user-login').val();
                        const confirmMsg = username ? 
                            'Are you sure you want to reset review limits for user "' + username + '"?' :
                            'Are you sure you want to reset review limits for ALL users?';
                            
                        if (confirm(confirmMsg)) {
                            $('#tool-results').html('<p>Resetting review limits...</p>').show();
                            
                            $.ajax({
                                url: ajaxurl,
                                type: 'POST',
                                data: {
                                    action: 'recenzuju_reset_review_limits',
                                    username: username
                                },
                                success: function(response) {
                                    if (response.success) {
                                        $('#tool-results').html('<p style="color: green;">✓ ' + response.data + '</p>');
                                    } else {
                                        $('#tool-results').html('<p style="color: red;">✗ ' + response.data + '</p>');
                                    }
                                },
                                error: function() {
                                    $('#tool-results').html('<p style="color: red;">✗ AJAX request failed.</p>');
                                }
                            });
                        }
                    });
                    
                    $('#check-tables').click(function(e) {
                        e.preventDefault();
                        $('#tool-results').html('<p>Checking database tables...</p>').show();
                        
                        $.ajax({
                            url: ajaxurl,
                            type: 'POST',
                            data: {
                                action: 'recenzuju_check_tables'
                            },
                            success: function(response) {
                                if (response.success) {
                                    $('#tool-results').html(response.data);
                                } else {
                                    $('#tool-results').html 

                                    $('#tool-results').html('<p style="color: red;">Error: ' + response.data + '</p>');
                                }
                            },
                            error: function() {
                                $('#tool-results').html('<p style="color: red;">✗ AJAX request failed.</p>');
                            }
                        });
                    });
                    
                    $('#export-reviews').click(function(e) {
                        e.preventDefault();
                        window.location.href = ajaxurl + '?action=recenzuju_export_reviews&_wpnonce=' + '<?php echo wp_create_nonce('recenzuju_export_reviews'); ?>';
                    });
                });
                </script>
            </div>
        </div>
    </div>
    <?php
}

// Render the analytics page
function recenzuju_render_analytics() {
    if (!current_user_can('manage_options')) {
        return;
    }
    ?>
    <div class="wrap">
        <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
        
        <!-- Date range selector -->
        <div class="date-range-selector card" style="padding: 15px; margin-bottom: 20px;">
            <h2>Filter Data</h2>
            <form id="analytics-filter-form">
                <div style="display: flex; gap: 15px; align-items: center; flex-wrap: wrap;">
                    <div>
                        <label for="date-from">From:</label>
                        <input type="date" id="date-from" name="date_from" value="<?php echo date('Y-m-d', strtotime('-30 days')); ?>">
                    </div>
                    <div>
                        <label for="date-to">To:</label>
                        <input type="date" id="date-to" name="date_to" value="<?php echo date('Y-m-d'); ?>">
                    </div>
                    <div>
                        <label for="user-filter">User:</label>
                        <input type="text" id="user-filter" name="user" placeholder="Any user">
                    </div>
                    <div>
                        <button type="submit" class="button button-primary">Apply Filters</button>
                        <button type="button" id="reset-filters" class="button button-secondary">Reset Filters</button>
                    </div>
                </div>
            </form>
        </div>
        
        <div class="analytics-widgets" style="display: flex; flex-wrap: wrap; gap: 20px;">
            <!-- Reviews Over Time Chart -->
            <div class="card" style="width: 100%; padding: 20px;">
                <h2>Reviews Over Time</h2>
                <div id="reviews-chart" style="width: 100%; height: 400px;">
                    <p>Loading chart...</p>
                </div>
            </div>
            
            <!-- Top Users -->
            <div class="card" style="width: calc(50% - 10px); min-width: 400px; padding: 20px;">
                <h2>Top Reviewers</h2>
                <div id="top-users-container">
                    <p>Loading top users...</p>
                </div>
            </div>
            
            <!-- Top Businesses -->
            <div class="card" style="width: calc(50% - 10px); min-width: 400px; padding: 20px;">
                <h2>Most Reviewed Businesses</h2>
                <div id="top-businesses-container">
                    <p>Loading top businesses...</p>
                </div>
            </div>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            function loadAnalyticsData() {
                const dateFrom = $('#date-from').val();
                const dateTo = $('#date-to').val();
                const user = $('#user-filter').val();
                
                // Show loading indicators
                $('#reviews-chart').html('<p>Loading chart...</p>');
                $('#top-users-container').html('<p>Loading top users...</p>');
                $('#top-businesses-container').html('<p>Loading top businesses...</p>');
                
                // Load reviews over time
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'recenzuju_get_reviews_over_time',
                        date_from: dateFrom,
                        date_to: dateTo,
                        user: user
                    },
                    success: function(response) {
                        if (response.success) {
                            renderReviewsChart(response.data);
                        } else {
                            $('#reviews-chart').html('<p style="color: red;">Error: ' + response.data + '</p>');
                        }
                    },
                    error: function() {
                        $('#reviews-chart').html('<p style="color: red;">AJAX request failed.</p>');
                    }
                });
                
                // Load top users
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'recenzuju_get_top_users',
                        date_from: dateFrom,
                        date_to: dateTo
                    },
                    success: function(response) {
                        if (response.success) {
                            renderTopUsers(response.data);
                        } else {
                            $('#top-users-container').html('<p style="color: red;">Error: ' + response.data + '</p>');
                        }
                    },
                    error: function() {
                        $('#top-users-container').html('<p style="color: red;">AJAX request failed.</p>');
                    }
                });
                
                // Load top businesses
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'recenzuju_get_top_businesses',
                        date_from: dateFrom,
                        date_to: dateTo,
                        user: user
                    },
                    success: function(response) {
                        if (response.success) {
                            renderTopBusinesses(response.data);
                        } else {
                            $('#top-businesses-container').html('<p style="color: red;">Error: ' + response.data + '</p>');
                        }
                    },
                    error: function() {
                        $('#top-businesses-container').html('<p style="color: red;">AJAX request failed.</p>');
                    }
                });
            }
            
            function renderReviewsChart(data) {
                if (!data || !data.dates || !data.counts) {
                    $('#reviews-chart').html('<p>No data available for the selected period.</p>');
                    return;
                }
                
                // If Chart.js is not loaded, add it
                if (typeof Chart === 'undefined') {
                    const script = document.createElement('script');
                    script.src = 'https://cdn.jsdelivr.net/npm/chart.js';
                    script.onload = function() {
                        createChart(data);
                    };
                    document.head.appendChild(script);
                } else {
                    createChart(data);
                }
                
                function createChart(data) {
                    $('#reviews-chart').html('<canvas id="reviewsCanvas" width="800" height="400"></canvas>');
                    
                    const ctx = document.getElementById('reviewsCanvas').getContext('2d');
                    new Chart(ctx, {
                        type: 'line',
                        data: {
                            labels: data.dates,
                            datasets: [{
                                label: 'Number of Reviews',
                                data: data.counts,
                                backgroundColor: 'rgba(54, 162, 235, 0.2)',
                                borderColor: 'rgba(54, 162, 235, 1)',
                                borderWidth: 2,
                                tension: 0.1
                            }]
                        },
                        options: {
                            scales: {
                                y: {
                                    beginAtZero: true,
                                    ticks: {
                                        precision: 0
                                    }
                                }
                            },
                            maintainAspectRatio: false,
                            responsive: true
                        }
                    });
                }
            }
            
            function renderTopUsers(data) {
                if (!data || data.length === 0) {
                    $('#top-users-container').html('<p>No data available for the selected period.</p>');
                    return;
                }
                
                let html = '<table class="wp-list-table widefat fixed striped">';
                html += '<thead><tr><th>Rank</th><th>Username</th><th>Reviews</th></tr></thead>';
                html += '<tbody>';
                
                data.forEach((user, index) => {
                    html += '<tr>';
                    html += '<td>' + (index + 1) + '</td>';
                    html += '<td>' + user.user_login + '</td>';
                    html += '<td>' + user.count + '</td>';
                    html += '</tr>';
                });
                
                html += '</tbody></table>';
                $('#top-users-container').html(html);
            }
            
            function renderTopBusinesses(data) {
                if (!data || data.length === 0) {
                    $('#top-businesses-container').html('<p>No data available for the selected period.</p>');
                    return;
                }
                
                let html = '<table class="wp-list-table widefat fixed striped">';
                html += '<thead><tr><th>Rank</th><th>Business URL</th><th>Reviews</th></tr></thead>';
                html += '<tbody>';
                
                data.forEach((business, index) => {
                    const displayUrl = business.google_maps_url.length > 50 
                        ? business.google_maps_url.substring(0, 47) + '...' 
                        : business.google_maps_url;
                        
                    html += '<tr>';
                    html += '<td>' + (index + 1) + '</td>';
                    html += '<td><a href="' + business.google_maps_url + '" target="_blank" title="' + business.google_maps_url + '">' 
                         + displayUrl + '</a></td>';
                    html += '<td>' + business.count + '</td>';
                    html += '</tr>';
                });
                
                html += '</tbody></table>';
                $('#top-businesses-container').html(html);
            }
            
            // Load initial data
            loadAnalyticsData();
            
            // Handle form submission
            $('#analytics-filter-form').on('submit', function(e) {
                e.preventDefault();
                loadAnalyticsData();
            });
            
            // Handle reset button
            $('#reset-filters').on('click', function() {
                $('#date-from').val(moment().subtract(30, 'days').format('YYYY-MM-DD'));
                $('#date-to').val(moment().format('YYYY-MM-DD'));
                $('#user-filter').val('');
                loadAnalyticsData();
            });
        });
        </script>
    </div>
    <?php
}

// Add the AJAX handlers for the admin functions

// Handler for testing database connection
add_action('wp_ajax_recenzuju_test_db_connection', 'recenzuju_test_db_connection_handler');

function recenzuju_test_db_connection_handler() {
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized access');
        return;
    }
    
    try {
        // Use the connection function with configured settings
        $conn = getConfiguredConnection();
        $stmt = $conn->query("SELECT 1");
        
        if ($stmt !== false) {
            wp_send_json_success("Database connection successful");
        } else {
            wp_send_json_error("Database connection failed with no specific error");
        }
    } catch (Exception $e) {
        wp_send_json_error($e->getMessage());
    }
}

// Handler for testing Airtable connection
add_action('wp_ajax_recenzuju_test_airtable_connection', 'recenzuju_test_airtable_connection_handler');

function recenzuju_test_airtable_connection_handler() {
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized access');
        return;
    }
    
    $api_key = get_option('recenzuju_airtable_api_key');
    $base_id = get_option('recenzuju_airtable_base_id');
    $table_id = get_option('recenzuju_airtable_table_id');
    
    if (empty($api_key) || empty($base_id) || empty($table_id)) {
        wp_send_json_error("Airtable settings are not fully configured");
        return;
    }
    
    try {
        $response = wp_remote_get("https://api.airtable.com/v0/{$base_id}/{$table_id}?maxRecords=1", [
            'headers' => [
                'Authorization' => "Bearer {$api_key}"
            ],
            'timeout' => 15
        ]);
        
        if (is_wp_error($response)) {
            wp_send_json_error($response->get_error_message());
            return;
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if ($status_code !== 200) {
            $error = isset($data['error']) ? $data['error']['message'] : "HTTP Error: {$status_code}";
            wp_send_json_error($error);
            return;
        }
        
        wp_send_json_success("Airtable connection successful");
        
    } catch (Exception $e) {
        wp_send_json_error($e->getMessage());
    }
}

// Handler for testing OpenAI connection
add_action('wp_ajax_recenzuju_test_openai_connection', 'recenzuju_test_openai_connection_handler');

function recenzuju_test_openai_connection_handler() {
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized access');
        return;
    }
    
    $api_key = get_option('recenzuju_openai_api_key');
    
    if (empty($api_key)) {
        wp_send_json_error("OpenAI API key is not configured");
        return;
    }
    
    try {
        $response = wp_remote_post("https://api.openai.com/v1/chat/completions", [
            'headers' => [
                'Authorization' => "Bearer {$api_key}",
                'Content-Type' => 'application/json'
            ],
            'body' => json_encode([
                'model' => 'gpt-3.5-turbo',
                'messages' => [
                    [
                        'role' => 'user',
                        'content' => 'Hello, this is a test message to verify API connectivity. Please respond with "connected".'
                    ]
                ],
                'max_tokens' => 10
            ]),
            'timeout' => 15
        ]);
        
        if (is_wp_error($response)) {
            wp_send_json_error($response->get_error_message());
            return;
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if ($status_code !== 200) {
            $error = isset($data['error']) ? $data['error']['message'] : "HTTP Error: {$status_code}";
            wp_send_json_error($error);
            return;
        }
        
        wp_send_json_success("OpenAI connection successful");
        
    } catch (Exception $e) {
        wp_send_json_error($e->getMessage());
    }
}

// Handler for system check
add_action('wp_ajax_recenzuju_run_system_check', 'recenzuju_run_system_check_handler');

function recenzuju_run_system_check_handler() {
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized access');
        return;
    }
    
    $results = '<h3>System Check Results</h3><ul>';
    
    // Check PHP version
    $php_version = phpversion();
    $php_ok = version_compare($php_version, '7.0', '>=');
    $results .= '<li>' . 
        ($php_ok ? '<span style="color: green; font-weight: bold;">✓</span>' : '<span style="color: red; font-weight: bold;">✗</span>') .
        ' PHP Version: ' . $php_version . 
        ($php_ok ? '' : ' (Recommended: 7.0 or higher)') .
        '</li>';
    
    // Check WordPress version
    global $wp_version;
    $wp_ok = version_compare($wp_version, '5.0', '>=');
    $results .= '<li>' . 
        ($wp_ok ? '<span style="color: green; font-weight: bold;">✓</span>' : '<span style="color: red; font-weight: bold;">✗</span>') .
        ' WordPress Version: ' . $wp_version . 
        ($wp_ok ? '' : ' (Recommended: 5.0 or higher)') .
        '</li>';
    
    // Check PDO extension
    $pdo_ok = extension_loaded('pdo_mysql');
    $results .= '<li>' . 
        ($pdo_ok ? '<span style="color: green; font-weight: bold;">✓</span>' : '<span style="color: red; font-weight: bold;">✗</span>') .
        ' PDO MySQL: ' . 
        ($pdo_ok ? 'Installed' : 'Not installed (Required)') .
        '</li>';
    
    // Check for cURL
    $curl_ok = extension_loaded('curl');
    $results .= '<li>' . 
        ($curl_ok ? '<span style="color: green; font-weight: bold;">✓</span>' : '<span style="color: red; font-weight: bold;">✗</span>') .
        ' cURL Extension: ' . 
        ($curl_ok ? 'Installed' : 'Not installed (Required for API connections)') .
        '</li>';
    
    // Check for proper database settings
    $db_host = get_option('recenzuju_db_host');
    $db_user = get_option('recenzuju_db_user');
    $db_pass = get_option('recenzuju_db_pass');
    $db_name = get_option('recenzuju_db_name');
    
    $db_settings_ok = !empty($db_host) && !empty($db_user) && !empty($db_pass) && !empty($db_name);
    $results .= '<li>' . 
        ($db_settings_ok ? '<span style="color: green; font-weight: bold;">✓</span>' : '<span style="color: orange; font-weight: bold;">!</span>') .
        ' Database Settings: ' . 
        ($db_settings_ok ? 'Configured' : 'Not fully configured') .
        '</li>';
    
    // Check for API settings
    $airtable_key = get_option('recenzuju_airtable_api_key');
    $airtable_base = get_option('recenzuju_airtable_base_id');
    $airtable_table = get_option('recenzuju_airtable_table_id');
    
    $airtable_ok = !empty($airtable_key) && !empty($airtable_base) && !empty($airtable_table);
    $results .= '<li>' . 
        ($airtable_ok ? '<span style="color: green; font-weight: bold;">✓</span>' : '<span style="color: red; font-weight: bold;">✗</span>') .
        ' Airtable Settings: ' . 
        ($airtable_ok ? 'Configured' : 'Not fully configured') .
        '</li>';
    
    $openai_key = get_option('recenzuju_openai_api_key');
    $openai_ok = !empty($openai_key);
    $results .= '<li>' . 
        ($openai_ok ? '<span style="color: green; font-weight: bold;">✓</span>' : '<span style="color: orange; font-weight: bold;">!</span>') .
        ' OpenAI API Key: ' . 
        ($openai_ok ? 'Configured' : 'Not configured (Fallback reviews will be used)') .
        '</li>';
    
    // Check database connection
    $db_connected = false;
    try {
        $conn = getConfiguredConnection();
        $stmt = $conn->query("SELECT 1");
        $db_connected = ($stmt !== false);
    } catch (Exception $e) {
        $db_error = $e->getMessage();
    }
    
    $results .= '<li>' . 
        ($db_connected ? '<span style="color: green; font-weight: bold;">✓</span>' : '<span style="color: red; font-weight: bold;">✗</span>') .
        ' Database Connection: ' . 
        ($db_connected ? 'Working' : 'Failed: ' . esc_html($db_error ?? 'Unknown error')) .
        '</li>';
    
    if ($db_connected) {
        // Check required tables
        try {
            $reviews_exists = $conn->query("SHOW TABLES LIKE 'reviews'")->rowCount() > 0;
            $results .= '<li>' . 
                ($reviews_exists ? '<span style="color: green; font-weight: bold;">✓</span>' : '<span style="color: red; font-weight: bold;">✗</span>') .
                ' Reviews Table: ' . 
                ($reviews_exists ? 'Exists' : 'Does not exist') .
                '</li>';
            
            $assignments_exists = $conn->query("SHOW TABLES LIKE 'assignments'")->rowCount() > 0;
            $results .= '<li>' . 
                ($assignments_exists ? '<span style="color: green; font-weight: bold;">✓</span>' : '<span style="color: red; font-weight: bold;">✗</span>') .
                ' Assignments Table: ' . 
                ($assignments_exists ? 'Exists' : 'Does not exist') .
                '</li>';
            
            // Check for orphaned records if assignments table exists
            if ($assignments_exists) {
                $stmt = $conn->query("
                    SELECT COUNT(*) as count 
                    FROM assignments 
                    WHERE status = 'assigned' 
                    AND assigned_date < DATE_SUB(NOW(), INTERVAL 30 MINUTE)
                ");
                $orphaned = $stmt->fetch(PDO::FETCH_ASSOC);
                
                $results .= '<li>' . 
                    ($orphaned['count'] == 0 ? '<span style="color: green; font-weight: bold;">✓</span>' : '<span style="color: orange; font-weight: bold;">!</span>') .
                    ' Orphaned Assignments: ' . 
                    $orphaned['count'] . 
                    '</li>';
            }
        } catch (Exception $e) {
            $results .= '<li><span style="color: red; font-weight: bold;">✗</span> Error checking tables: ' . esc_html($e->getMessage()) . '</li>';
        }
    }
    
    $results .= '</ul>';
    
    // Summary and recommendations
    $results .= '<h3>Summary</h3>';
    $results .= '<p>The following issues need to be addressed:</p>';
    $results .= '<ul>';
    
    if (!$php_ok) {
        $results .= '<li>Update PHP to version 7.0 or higher</li>';
    }
    
    if (!$wp_ok) {
        $results .= '<li>Update WordPress to version 5.0 or higher</li>';
    }
    
    if (!$pdo_ok) {
        $results .= '<li>Install PHP PDO MySQL extension</li>';
    }
    
    if (!$curl_ok) {
        $results .= '<li>Install PHP cURL extension</li>';
    }
    
    if (!$db_settings_ok) {
        $results .= '<li>Configure database settings</li>';
    }
    
    if (!$airtable_ok) {
        $results .= '<li>Configure Airtable API settings</li>';
    }
    
    if (!$openai_ok) {
        $results .= '<li>Configure OpenAI API key for AI-generated reviews</li>';
    }
    
    if (!$db_connected) {
        $results .= '<li>Fix database connection issues</li>';
    } else {
        if (isset($reviews_exists) && !$reviews_exists) {
            $results .= '<li>Create or repair the reviews table</li>';
        }
        
        if (isset($assignments_exists) && !$assignments_exists) {
            $results .= '<li>Create or repair the assignments table</li>';
        }
        
        if (isset($orphaned) && $orphaned['count'] > 0) {
            $results .= '<li>Release ' . $orphaned['count'] . ' orphaned assignments</li>';
        }
    }
    
    if ($php_ok && $wp_ok && $pdo_ok && $curl_ok && $db_settings_ok && $airtable_ok && $db_connected 
        && (isset($reviews_exists) && $reviews_exists) && (isset($assignments_exists) && $assignments_exists)
        && (isset($orphaned) && $orphaned['count'] == 0)) {
        $results .= '<li>All critical checks passed! The system is properly configured.</li>';
    }
    
    $results .= '</ul>';
    
    wp_send_json_success($results);
}

// Handler for releasing orphaned assignments
add_action('wp_ajax_recenzuju_release_orphaned', 'recenzuju_release_orphaned_handler');

function recenzuju_release_orphaned_handler() {
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized access');
        return;
    }
    
    try {
        $conn = getConfiguredConnection();
        
        $stmt = $conn->prepare("
            UPDATE assignments 
            SET status = 'unassigned', 
                user_name = NULL,
                assigned_date = NULL
            WHERE status = 'assigned' 
            AND assigned_date < DATE_SUB(NOW(), INTERVAL ? MINUTE)
        ");
        
        $timeout = get_option('recenzuju_assignment_timeout', 30);
        $stmt->execute([$timeout]);
        
        $count = $stmt->rowCount();
        
        if ($count > 0) {
            wp_send_json_success("Successfully released {$count} orphaned assignment(s)");
        } else {
            wp_send_json_success("No orphaned assignments found");
        }
        
    } catch (Exception $e) {
        wp_send_json_error("Error: " . $e->getMessage());
    }
}

// Handler for resetting review limits
add_action('wp_ajax_recenzuju_reset_review_limits', 'recenzuju_reset_review_limits_handler');

function recenzuju_reset_review_limits_handler() {
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized access');
        return;
    }
    
    $username = isset($_POST['username']) ? sanitize_text_field($_POST['username']) : '';
    
    try {
        $conn = getConfiguredConnection();
        
        if (empty($username)) {
            // Reset for all users
            $stmt = $conn->query("
                DELETE FROM reviews 
                WHERE review_date >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
            ");
            
            $count = $stmt->rowCount();
            wp_send_json_success("Reset review limits for all users. Deleted {$count} review(s)");
        } else {
            // Reset for specific user
            $stmt = $conn->prepare("
                DELETE FROM reviews 
                WHERE user_login = ? 
                AND review_date >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
            ");
            
            $stmt->execute([$username]);
            $count = $stmt->rowCount();
            
            if ($count > 0) {
                wp_send_json_success("Reset review limits for user '{$username}'. Deleted {$count} review(s)");
            } else {
                wp_send_json_success("No recent reviews found for user '{$username}'");
            }
        }
        
    } catch (Exception $e) {
        wp_send_json_error("Error: " . $e->getMessage());
    }
}

// Handler for checking and repairing tables
add_action('wp_ajax_recenzuju_check_tables', 'recenzuju_check_tables_handler');

function recenzuju_check_tables_handler() {
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized access');
        return;
    }
    
    try {
        $conn = getConfiguredConnection();
        $results = '<h3>Table Check Results</h3>';
        
        // Check reviews table
        $reviews_exists = $conn->query("SHOW TABLES LIKE 'reviews'")->rowCount() > 0;
        
        if (!$reviews_exists) {
            // Create reviews table
            $conn->exec("
                CREATE TABLE IF NOT EXISTS reviews (
                    id INT(11) NOT NULL AUTO_INCREMENT,
                    user_login VARCHAR(100) NOT NULL,
                    google_maps_url VARCHAR(255) NOT NULL,
                    review_text TEXT,
                    review_date DATETIME NOT NULL,
                    PRIMARY KEY (id),
                    INDEX idx_user_date (user_login, review_date),
                    INDEX idx_urls (google_maps_url),
                    UNIQUE KEY unique_user_url (user_login, google_maps_url)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            ");
            
            $results .= '<p><span style="color: green; font-weight: bold;">✓</span> Created reviews table</p>';
        } else {
            // Check structure and repair if needed
            $missing_indexes = [];
            
            // Check for indexes
            $indexes = $conn->query("SHOW INDEX FROM reviews")->fetchAll(PDO::FETCH_ASSOC);
            $index_names = array_column($indexes, 'Key_name');
            
            if (!in_array('idx_user_date', $index_names)) {
                $missing_indexes[] = 'idx_user_date';
            }
            
            if (!in_array('idx_urls', $index_names)) {
                $missing_indexes[] = 'idx_urls';
            }
            
            if (!in_array('unique_user_url', $index_names)) {
                $missing_indexes[] = 'unique_user_url';
            }
            
            if (!empty($missing_indexes)) {
              foreach ($missing_indexes as $index) {
                try {
                    if ($index === 'idx_user_date') {
                        $conn->exec("ALTER TABLE reviews ADD INDEX idx_user_date (user_login, review_date)");
                    } elseif ($index === 'idx_urls') {
                        $conn->exec("ALTER TABLE reviews ADD INDEX idx_urls (google_maps_url)");
                    } elseif ($index === 'unique_user_url') {
                        $conn->exec("ALTER TABLE reviews ADD UNIQUE KEY unique_user_url (user_login, google_maps_url)");
                    }
                    $results .= '<p><span style="color: green; font-weight: bold;">✓</span> Added missing index: ' . $index . '</p>';
                } catch (Exception $e) {
                    $results .= '<p><span style="color: red; font-weight: bold;">✗</span> Failed to add index ' . $index . ': ' . $e->getMessage() . '</p>';
                }
            }
        }
        
        // Check for REPAIR/OPTIMIZE if MySQL
        try {
            $conn->exec("REPAIR TABLE reviews");
            $conn->exec("OPTIMIZE TABLE reviews");
            $results .= '<p><span style="color: green; font-weight: bold;">✓</span> Repaired and optimized reviews table</p>';
        } catch (Exception $e) {
            // Ignore errors as this might not be supported on all DB types
            $results .= '<p><span style="color: orange; font-weight: bold;">!</span> Could not repair/optimize reviews table (may be normal for some DB types)</p>';
        }
    }
    
    // Check assignments table
    $assignments_exists = $conn->query("SHOW TABLES LIKE 'assignments'")->rowCount() > 0;
    
    if (!$assignments_exists) {
        // Not creating assignments table as it's likely managed by other systems
        $results .= '<p><span style="color: orange; font-weight: bold;">!</span> Assignments table does not exist. This is managed by the Airtable integration.</p>';
    } else {
        // Check for needed columns
        $columns_query = $conn->query("SHOW COLUMNS FROM assignments");
        $columns = $columns_query->fetchAll(PDO::FETCH_COLUMN);
        
        $missing_columns = [];
        $needed_columns = [
            'status', 'user_name', 'assigned_date', 'platform_url', 'last_ping'
        ];
        
        foreach ($needed_columns as $column) {
            if (!in_array($column, $columns)) {
                $missing_columns[] = $column;
            }
        }
        
        if (!empty($missing_columns)) {
            $results .= '<p><span style="color: orange; font-weight: bold;">!</span> Missing columns in assignments table: ' . implode(', ', $missing_columns) . '</p>';
            $results .= '<p>These might be handled by the Airtable integration - please check your field mappings.</p>';
        } else {
            $results .= '<p><span style="color: green; font-weight: bold;">✓</span> All required columns exist in assignments table</p>';
        }
        
        // Check for orphaned records
        $stmt = $conn->query("
            SELECT COUNT(*) as count 
            FROM assignments 
            WHERE status = 'assigned' 
            AND assigned_date < DATE_SUB(NOW(), INTERVAL 30 MINUTE)
        ");
        $orphaned = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($orphaned['count'] > 0) {
            $results .= '<p><span style="color: orange; font-weight: bold;">!</span> Found ' . $orphaned['count'] . ' orphaned assignment(s). Use the "Release Orphaned" tool to fix this.</p>';
        } else {
            $results .= '<p><span style="color: green; font-weight: bold;">✓</span> No orphaned assignments found</p>';
        }
    }
    
    wp_send_json_success($results);
    
} catch (Exception $e) {
    wp_send_json_error("Error: " . $e->getMessage());
}
}

// Handler for exporting reviews to CSV
add_action('wp_ajax_recenzuju_export_reviews', 'recenzuju_export_reviews_handler');

function recenzuju_export_reviews_handler() {
if (!current_user_can('manage_options') || !check_ajax_referer('recenzuju_export_reviews', false, false)) {
    wp_die('Unauthorized access');
    return;
}

try {
    $conn = getConfiguredConnection();
    
    $stmt = $conn->query("
        SELECT id, user_login, google_maps_url, review_text, review_date 
        FROM reviews 
        ORDER BY review_date DESC
    ");
    
    $reviews = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($reviews)) {
        echo "No reviews found to export.";
        exit;
    }
    
    // Set headers for CSV download
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="reviews_export_' . date('Y-m-d') . '.csv"');
    
    // Create output file pointer
    $output = fopen('php://output', 'w');
    
    // Add UTF-8 BOM for Excel compatibility
    fputs($output, "\xEF\xBB\xBF");
    
    // Add column headers
    fputcsv($output, array_keys($reviews[0]));
    
    // Output each review as a CSV row
    foreach ($reviews as $review) {
        fputcsv($output, $review);
    }
    
    fclose($output);
    exit;
    
} catch (Exception $e) {
    echo "Error exporting reviews: " . $e->getMessage();
    exit;
}
}

// Handlers for analytics data

add_action('wp_ajax_recenzuju_get_reviews_over_time', 'recenzuju_get_reviews_over_time_handler');

function recenzuju_get_reviews_over_time_handler() {
if (!current_user_can('manage_options')) {
    wp_send_json_error('Unauthorized access');
    return;
}

$date_from = isset($_POST['date_from']) ? sanitize_text_field($_POST['date_from']) : date('Y-m-d', strtotime('-30 days'));
$date_to = isset($_POST['date_to']) ? sanitize_text_field($_POST['date_to']) : date('Y-m-d');
$user = isset($_POST['user']) ? sanitize_text_field($_POST['user']) : '';

try {
    $conn = getConfiguredConnection();
    
    // Build the query
    $query = "
        SELECT DATE(review_date) as day, COUNT(*) as count 
        FROM reviews 
        WHERE review_date BETWEEN ? AND ? 
    ";
    
    $params = [$date_from . ' 00:00:00', $date_to . ' 23:59:59'];
    
    if (!empty($user)) {
        $query .= " AND user_login = ? ";
        $params[] = $user;
    }
    
    $query .= " GROUP BY day ORDER BY day";
    
    $stmt = $conn->prepare($query);
    $stmt->execute($params);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Fill in any missing dates with zero values
    $date_range = getDatesInRange($date_from, $date_to);
    $counts_by_date = [];
    
    foreach ($results as $row) {
        $counts_by_date[$row['day']] = (int) $row['count'];
    }
    
    $dates = [];
    $counts = [];
    
    foreach ($date_range as $date) {
        $dates[] = $date;
        $counts[] = isset($counts_by_date[$date]) ? $counts_by_date[$date] : 0;
    }
    
    wp_send_json_success([
        'dates' => $dates,
        'counts' => $counts
    ]);
    
} catch (Exception $e) {
    wp_send_json_error("Error: " . $e->getMessage());
}
}

add_action('wp_ajax_recenzuju_get_top_users', 'recenzuju_get_top_users_handler');

function recenzuju_get_top_users_handler() {
if (!current_user_can('manage_options')) {
    wp_send_json_error('Unauthorized access');
    return;
}

$date_from = isset($_POST['date_from']) ? sanitize_text_field($_POST['date_from']) : date('Y-m-d', strtotime('-30 days'));
$date_to = isset($_POST['date_to']) ? sanitize_text_field($_POST['date_to']) : date('Y-m-d');

try {
    $conn = getConfiguredConnection();
    
    $stmt = $conn->prepare("
        SELECT user_login, COUNT(*) as count 
        FROM reviews 
        WHERE review_date BETWEEN ? AND ? 
        GROUP BY user_login 
        ORDER BY count DESC 
        LIMIT 10
    ");
    
    $stmt->execute([$date_from . ' 00:00:00', $date_to . ' 23:59:59']);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    wp_send_json_success($results);
    
} catch (Exception $e) {
    wp_send_json_error("Error: " . $e->getMessage());
}
}

add_action('wp_ajax_recenzuju_get_top_businesses', 'recenzuju_get_top_businesses_handler');

function recenzuju_get_top_businesses_handler() {
if (!current_user_can('manage_options')) {
    wp_send_json_error('Unauthorized access');
    return;
}

$date_from = isset($_POST['date_from']) ? sanitize_text_field($_POST['date_from']) : date('Y-m-d', strtotime('-30 days'));
$date_to = isset($_POST['date_to']) ? sanitize_text_field($_POST['date_to']) : date('Y-m-d');
$user = isset($_POST['user']) ? sanitize_text_field($_POST['user']) : '';

try {
    $conn = getConfiguredConnection();
    
    // Build the query
    $query = "
        SELECT google_maps_url, COUNT(*) as count 
        FROM reviews 
        WHERE review_date BETWEEN ? AND ? 
    ";
    
    $params = [$date_from . ' 00:00:00', $date_to . ' 23:59:59'];
    
    if (!empty($user)) {
        $query .= " AND user_login = ? ";
        $params[] = $user;
    }
    
    $query .= " GROUP BY google_maps_url ORDER BY count DESC LIMIT 10";
    
    $stmt = $conn->prepare($query);
    $stmt->execute($params);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    wp_send_json_success($results);
    
} catch (Exception $e) {
    wp_send_json_error("Error: " . $e->getMessage());
}
}

// Helper functions

// Get a database connection using configured settings
function getConfiguredConnection() {
$db_host = get_option('recenzuju_db_host');
$db_user = get_option('recenzuju_db_user');
$db_pass = get_option('recenzuju_db_pass');
$db_name = get_option('recenzuju_db_name');

// If settings are configured, use them
if (!empty($db_host) && !empty($db_user) && !empty($db_name)) {
    try {
        $conn = new PDO(
            "mysql:host={$db_host};dbname={$db_name}",
            $db_user,
            $db_pass,
            array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION)
        );
        return $conn;
    } catch (PDOException $e) {
        throw new Exception("Database Connection Error: " . $e->getMessage());
    }
}

// Otherwise, fall back to the original getConnection function
return getConnection();
}

// Override getConnection function if needed
function getConnection() {
try {
    // First try to use configured settings
    $conn = getConfiguredConnection();
    return $conn;
} catch (Exception $e) {
    // If that fails, use original hardcoded credentials
    try {
        $db_host = 'db.dw170.webglobe.com';
        $db_user = 'nodejs_user';
        $db_pass = 'PIXGEVUn5';
        $db_name = 'review_assignments';
        
        $conn = new PDO(
            "mysql:host={$db_host};dbname={$db_name}",
            $db_user,
            $db_pass,
            array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION)
        );
        
        return $conn;
    } catch (PDOException $e) {
        error_log("Database Connection Error: " . $e->getMessage());
        throw $e;
    }
}
}

// Generate an array of dates between two dates
function getDatesInRange($start_date, $end_date) {
$dates = [];
$current = strtotime($start_date);
$end = strtotime($end_date);

while ($current <= $end) {
    $dates[] = date('Y-m-d', $current);
    $current = strtotime('+1 day', $current);
}

return $dates;
}

// Modify the JS client to use API keys from settings
function recenzuju_enqueue_custom_js() {
// Only do this on pages that have the feedback form
global $post;
if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'feedback_form')) {
    // Get settings
    $airtable_api_key = get_option('recenzuju_airtable_api_key');
    $airtable_base_id = get_option('recenzuju_airtable_base_id');
    $airtable_table_id = get_option('recenzuju_airtable_table_id');
    $openai_api_key = get_option('recenzuju_openai_api_key');
    $assignment_timeout = get_option('recenzuju_assignment_timeout', 30);
    
    // Only override if all values are set
    if (!empty($airtable_api_key) && !empty($airtable_base_id) && !empty($airtable_table_id)) {
        wp_add_inline_script('feedback-form-script', "
            // Override Airtable configuration
            const airtableApiKey = \"" . esc_js($airtable_api_key) . "\";
            const airtableBaseId = \"" . esc_js($airtable_base_id) . "\";
            const airtableTableId = \"" . esc_js($airtable_table_id) . "\";
            
            // Override OpenAI configuration if set
            " . (!empty($openai_api_key) ? "const OPENAI_API_KEY = \"" . esc_js($openai_api_key) . "\";" : "") . "
            
            // Override timeout settings
            const ASSIGNMENT_MAX_IDLE_TIME = " . (intval($assignment_timeout) * 60000) . "; // Convert minutes to milliseconds
        ", 'before');
    }
}
}

add_action('wp_enqueue_scripts', 'recenzuju_enqueue_custom_js', 100);

// Add styles for admin pages
function recenzuju_admin_styles() {
wp_enqueue_style('recenzuju-admin-styles', plugins_url('assets/admin-styles.css', __FILE__));
}

add_action('admin_enqueue_scripts', 'recenzuju_admin_styles');

// Create admin styles file
function recenzuju_create_admin_styles() {
$admin_styles = "/* Admin styles for Recenzuju plugin */
.card {
background: #fff;
border: 1px solid #e5e5e5;
box-shadow: 0 1px 1px rgba(0,0,0,.04);
margin-top: 20px;
padding: 20px;
position: relative;
}

.tools-grid .tool-card {
transition: all 0.2s ease;
}

.tools-grid .tool-card:hover {
background: #f5f5f5;
box-shadow: 0 2px 5px rgba(0,0,0,.1);
}

.notice-bar {
background: #f8f8f8;
border-left: 4px solid #bbb;
margin: 15px 0;
padding: 12px;
}

.notice-bar.error {
border-color: #dc3232;
}

.notice-bar.warning {
border-color: #ffb900;
}

.notice-bar.success {
border-color: #46b450;
}

.notice-bar.info {
border-color: #00a0d2;
}

.health-checks li {
margin-bottom: 10px;
}
";

$css_dir = plugin_dir_path(__FILE__) . 'assets';

// Create directory if it doesn't exist
if (!file_exists($css_dir)) {
    mkdir($css_dir, 0755, true);
}

file_put_contents($css_dir . '/admin-styles.css', $admin_styles);
}

// Run during plugin activation
register_activation_hook(__FILE__, 'recenzuju_plugin_activate');

function recenzuju_plugin_activate() {
// Create admin styles file
recenzuju_create_admin_styles();

// Initialize settings with defaults
if (get_option('recenzuju_daily_review_limit') === false) {
    update_option('recenzuju_daily_review_limit', 3);
}

if (get_option('recenzuju_assignment_timeout') === false) {
    update_option('recenzuju_assignment_timeout', 30);
}

// Check if database settings are empty, try to fill from existing code
if (empty(get_option('recenzuju_db_host'))) {
    // Extract from the original getConnection function
    $php_code = file_get_contents(__FILE__);
    
    if (preg_match('/\$db_host\s*=\s*[\'"](.*?)[\'"]/i', $php_code, $matches)) {
        update_option('recenzuju_db_host', $matches[1]);
    }
    
    if (preg_match('/\$db_user\s*=\s*[\'"](.*?)[\'"]/i', $php_code, $matches)) {
        update_option('recenzuju_db_user', $matches[1]);
    }
    
    if (preg_match('/\$db_pass\s*=\s*[\'"](.*?)[\'"]/i', $php_code, $matches)) {
        update_option('recenzuju_db_pass', $matches[1]);
    }
    
    if (preg_match('/\$db_name\s*=\s*[\'"](.*?)[\'"]/i', $php_code, $matches)) {
        update_option('recenzuju_db_name', $matches[1]);
    }
}

// Extract Airtable settings from JavaScript
$js_file = plugin_dir_path(__FILE__) . 'assets/script.js';
if (file_exists($js_file)) {
    $js_code = file_get_contents($js_file);
    
    if (preg_match('/airtableApiKey\s*=\s*[\'"](.*?)[\'"]/i', $js_code, $matches)) {
        update_option('recenzuju_airtable_api_key', $matches[1]);
    }
    
    if (preg_match('/airtableBaseId\s*=\s*[\'"](.*?)[\'"]/i', $js_code, $matches)) {
        update_option('recenzuju_airtable_base_id', $matches[1]);
    }
    
    if (preg_match('/airtableTableId\s*=\s*[\'"](.*?)[\'"]/i', $js_code, $matches)) {
        update_option('recenzuju_airtable_table_id', $matches[1]);
    }
    
    if (preg_match('/OPENAI_API_KEY\s*=\s*[\'"](.*?)[\'"]/i', $js_code, $matches)) {
        update_option('recenzuju_openai_api_key', $matches[1]);
    }
}

// Ensure database tables exist
ensure_reviews_table_exists();
}