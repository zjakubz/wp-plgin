<?php
/*
Plugin Name: Recenzuju Feedback Form
Description: A plugin for displaying a feedback form with AI-generated reviews and options.
Version: 1.0
Author: Your Name
*/

// ------------------------------
// 1) DB constants + connection
// ------------------------------
// Include admin settings
require_once plugin_dir_path(__FILE__) . 'admin-settings.php';

// Make settings available globally
function recenzuju_get_settings() {
    return array(
        'db_host' => get_option('recenzuju_db_host', 'db.dw170.webglobe.com'),
        'db_user' => get_option('recenzuju_db_user', 'nodejs_user'),
        'db_pass' => get_option('recenzuju_db_pass', 'PIXGEVUn5'),
        'db_name' => get_option('recenzuju_db_name', 'review_assignments'),
        'airtable_api_key' => get_option('recenzuju_airtable_api_key', 'patk8IhaVsT23lzkX.a0bcbcc0b7b2ced435c4b843a0fc52660f68cfb20f6d1bfd50a6a1ff7b901b6d'),
        'airtable_base_id' => get_option('recenzuju_airtable_base_id', 'apphpjWQemBVF3uJc'),
        'airtable_table_id' => get_option('recenzuju_airtable_table_id', 'tblV2HSxR3Aecvv74'),
        'openai_api_key' => get_option('recenzuju_openai_api_key', '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'),
        'daily_review_limit' => get_option('recenzuju_daily_review_limit', 3),
        'assignment_timeout' => get_option('recenzuju_assignment_timeout', 30),
        'debug_mode' => get_option('recenzuju_enable_debug_mode', false),
    );
}
function getConnection() {
try {
// Define these directly in the function to ensure they're used
$db_host = 'db.dw170.webglobe.com';
$db_user = 'nodejs_user';
$db_pass = 'PIXGEVUn5';
$db_name = 'review_assignments';

// Log connection attempt
error_log("Attempting database connection to {$db_host} as {$db_user}");

$conn = new PDO(
"mysql:host={$db_host};dbname={$db_name}",
$db_user,
$db_pass,
array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION)
);

// Test the connection with a simple query
$stmt = $conn->query("SELECT 1");
error_log("Database connection successful");

return $conn;
} catch (PDOException $e) {
error_log("Database Connection Error: " . $e->getMessage());
throw $e; // Re-throw to be caught by the calling function
}
}
// Add this after getConnection()
// Modify your table creation function
function ensure_reviews_table_exists() {
try {
$conn = getConnection();

// Check if the reviews table exists
$stmt = $conn->query("SHOW TABLES LIKE 'reviews'");
$tableExists = $stmt->rowCount() > 0;

if (!$tableExists) {
error_log("Reviews table does not exist - creating it");

// Create the table with better constraints
$sql = "CREATE TABLE IF NOT EXISTS reviews (
id INT(11) NOT NULL AUTO_INCREMENT,
user_login VARCHAR(100) NOT NULL,
google_maps_url VARCHAR(255) NOT NULL,
review_text TEXT,
review_date DATETIME NOT NULL,
PRIMARY KEY (id),
INDEX idx_user_date (user_login, review_date),
INDEX idx_urls (google_maps_url),
UNIQUE KEY unique_user_url (user_login, google_maps_url)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

$conn->exec($sql);
error_log("Reviews table created successfully");
} else {
// Check if the unique constraint exists, add it if not
try {
$conn->exec("ALTER TABLE reviews ADD UNIQUE KEY unique_user_url (user_login, google_maps_url)");
error_log("Added unique constraint to reviews table");
} catch (Exception $e) {
// Constraint might already exist, that's fine
}

// Check if indexes exist, add them if not
try {
$conn->exec("ALTER TABLE reviews ADD INDEX idx_user_date (user_login, review_date)");
error_log("Added user/date index to reviews table");
} catch (Exception $e) {
// Index might already exist, that's fine
}
}

return true;
} catch (Exception $e) {
error_log("Error ensuring reviews table exists: " . $e->getMessage());
return false;
}
}
// Function to check if user has reached daily review limit (3 per 24 hours)
// Function to check if user has reached daily review limit (3 per 24 hours)
// Function to check if user has reached daily review limit (3 per 24 hours)
function has_reached_daily_review_limit($user_login) {
try {
$conn = getConnection();

// Count reviews submitted in the last 24 hours
$stmt = $conn->prepare("
SELECT COUNT(*) AS review_count 
FROM reviews 
WHERE user_login = ? 
AND review_date >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
");
$stmt->execute([$user_login]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

$count = $result && isset($result['review_count']) ? (int)$result['review_count'] : 0;

// Debug log the actual count
error_log("User {$user_login} has written {$count} reviews in the last 24 hours");

// Check if count is 3 or more
return ($count >= 3);

} catch (Exception $e) {
error_log("Error checking daily review limit: " . $e->getMessage());
return false; // Default to allowing reviews if there's an error checking
}
}

// Add a new AJAX endpoint to get review count
add_action('wp_ajax_get_user_review_count', 'get_user_review_count_handler');
add_action('wp_ajax_nopriv_get_user_review_count', 'get_user_review_count_handler');

function get_user_review_count_handler() {
if (!is_user_logged_in()) {
wp_send_json_error("Not logged in");
return;
}

$current_user = wp_get_current_user();
$userLogin = $current_user->user_login;

try {
$conn = getConnection();

// Count reviews submitted in the last 24 hours
$stmt = $conn->prepare("
SELECT COUNT(*) AS review_count 
FROM reviews 
WHERE user_login = ? 
AND review_date >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
");
$stmt->execute([$userLogin]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

$count = $result && isset($result['review_count']) ? (int)$result['review_count'] : 0;
$remaining = 3 - $count;

wp_send_json_success([
'count' => $count,
'remaining' => max(0, $remaining),
'limit_reached' => $count >= 3
]);

} catch (Exception $e) {
error_log("Error getting user review count: " . $e->getMessage());
wp_send_json_error("Database error: " . $e->getMessage());
}
}

// Function to check if user's gender matches the review requirement
function is_gender_compatible($user_gender, $review_gender) {
// If review is for any gender, always return true
if ($review_gender == 'any') {
return true;
}

// Normalize gender values for comparison
$normalized_user_gender = strtolower(trim($user_gender));
$normalized_review_gender = strtolower(trim($review_gender));

// Map Czech gender terms to standard values
if ($normalized_user_gender == 'muž' || $normalized_user_gender == 'muz') {
$normalized_user_gender = 'male';
} elseif ($normalized_user_gender == 'žena' || $normalized_user_gender == 'zena') {
$normalized_user_gender = 'female';
}

// Return true if genders match
return ($normalized_user_gender == $normalized_review_gender);
}

// Call this function when the plugin initializes
add_action('init', 'ensure_reviews_table_exists');
// ----------------------------------------------------
// 2) AJAX #1: get_random_unassigned
// (Find a random unassigned assignment row that
// the user hasn't already reviewed. Assign it to user.)
// ----------------------------------------------------
add_action('wp_ajax_get_random_unassigned', 'get_random_unassigned_handler');
add_action('wp_ajax_nopriv_get_random_unassigned', 'get_random_unassigned_handler');
add_action('wp_ajax_get_random_unassigned', 'get_random_unassigned_handler');
add_action('wp_ajax_nopriv_get_random_unassigned', 'get_random_unassigned_handler');
function get_random_unassigned_handler() {
// Must be logged in
if (!is_user_logged_in()) {
wp_send_json_error("Not logged in");
}
$current_user = wp_get_current_user();
$userLogin = $current_user->user_login;

if (has_reached_daily_review_limit($userLogin)) {
wp_send_json_error("Dosáhli jste denního limitu 3 recenzí za 24 hodin.");
return;
}

try {
$conn = getConnection();

// Attempt multiple times to find a valid row
$maxAttempts = 5;
$foundRecord = null;

for ($i = 0; $i < $maxAttempts; $i++) {
// 1) Pick a random row that is "unassigned" AND not yet completed
$stmt = $conn->query("
SELECT * 
FROM assignments
WHERE (user_name IS NULL OR user_name = '')
AND (status IS NULL OR status != 'completed')
ORDER BY RAND()
LIMIT 1
");
$row = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$row) {
// No unassigned rows left
break;
}

$platformUrl = $row['platform_url'];

// 2) Check if user already wrote a review for that same platform_url
// in `reviews` table
$stmt2 = $conn->prepare("
SELECT id 
FROM reviews
WHERE user_login = ? 
AND google_maps_url = ?
LIMIT 1
");
$stmt2->execute([$userLogin, $platformUrl]);
$alreadyExists = $stmt2->fetch(PDO::FETCH_ASSOC);

if ($alreadyExists) {
// user already wrote a review for this URL => skip it
continue;
}

// 3) Mark the assignment as "assigned" to this user
$stmt3 = $conn->prepare("
UPDATE assignments
SET user_name = ?,
assigned_date = NOW(),
status = 'assigned'
WHERE id = ?
");
$stmt3->execute([$userLogin, $row['id']]);

// We got a valid match; store it and break
$foundRecord = $row;
break;
}

if ($foundRecord) {
wp_send_json_success($foundRecord);
} else {
wp_send_json_error("No suitable unassigned records.");
}
} catch (Exception $e) {
wp_send_json_error("DB Error: " . $e->getMessage());
}
}


// ----------------------------------------------------
// 3) AJAX #2: confirm_review
// (User confirms they wrote the review => insert
// into `reviews` and optionally mark assignment as done.)
// ----------------------------------------------------
add_action('wp_ajax_confirm_review', 'confirm_review_handler');
add_action('wp_ajax_nopriv_confirm_review', 'confirm_review_handler');
// Modify your confirm_review_handler function to use a transaction
function confirm_review_handler() {
if (!is_user_logged_in()) {
wp_send_json_error("Not logged in");
return;
}

$current_user = wp_get_current_user();
$userLogin = $current_user->user_login;

try {
$conn = getConnection();

// Start transaction
$conn->beginTransaction();

// Check limit INSIDE transaction to prevent race conditions
$stmt = $conn->prepare("
SELECT COUNT(*) AS review_count 
FROM reviews 
WHERE user_login = ? 
AND review_date >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
FOR UPDATE
");
$stmt->execute([$userLogin]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result && isset($result['review_count']) && $result['review_count'] >= 3) {
$conn->rollBack();
wp_send_json_error("Dosáhli jste denního limitu 3 recenzí za 24 hodin.");
return;
}

// Get the platform URL, which is what we need to save to the database
$platformUrl = isset($_POST['platform_url']) ? trim($_POST['platform_url']) : '';
$reviewText = isset($_POST['review_text']) ? trim($_POST['review_text']) : '';

if (empty($platformUrl)) {
$conn->rollBack();
wp_send_json_error("Missing platform_url");
return;
}

// Insert the review
$sql = "INSERT INTO reviews (user_login, google_maps_url, review_text, review_date) 
VALUES (?, ?, ?, NOW())";

$stmt = $conn->prepare($sql);
$success = $stmt->execute([$userLogin, $platformUrl, $reviewText]);

if (!$success) {
$conn->rollBack();
wp_send_json_error("Failed to save review");
return;
}

// Commit the transaction
$conn->commit();

wp_send_json_success("Review saved successfully");

} catch (Exception $e) {
// Roll back transaction on error
if (isset($conn) && $conn->inTransaction()) {
$conn->rollBack();
}
error_log("Error in confirm_review_handler: " . $e->getMessage());
wp_send_json_error("Database error: " . $e->getMessage());
}
}


// ----------------------------------------------------
// 4) Register + enqueue scripts and localize
// ----------------------------------------------------
function feedback_form_assets() {
// Enqueue jQuery
wp_enqueue_script('jquery');

// Enqueue your plugin’s CSS
wp_enqueue_style(
'feedback-form-style',
plugin_dir_url(__FILE__) . 'assets/style.css',
array(),
'1.0'
);

// Enqueue your plugin’s JS (script.js)
wp_enqueue_script(
'feedback-form-script',
plugin_dir_url(__FILE__) . 'assets/script.js',
array('jquery'),
'1.0',
true
);

// Localize the AJAX URL
$ajax_data = array(
'ajax_url' => admin_url('admin-ajax.php')
);

// If user is logged in, pass metadata to JS
$user_data = array();
if ( is_user_logged_in() ) {
$current_user = wp_get_current_user();
$user_data = array(
'id' => $current_user->ID,
'user_login' => $current_user->user_login,
'first_name' => get_user_meta( $current_user->ID, 'first_name', true ),
'gender' => get_user_meta( $current_user->ID, 'gender', true ),
'google_review_profile_link' => get_user_meta( $current_user->ID, 'google-review-profile-link', true )
);
}

// localize both data sets
wp_localize_script('feedback-form-script', 'feedback_form_ajax', $ajax_data);
wp_localize_script('feedback-form-script', 'umUserData', $user_data);
}

// Add an AJAX endpoint to check if user already reviewed this business
add_action('wp_ajax_check_existing_business_review', 'check_existing_business_review_handler');
add_action('wp_ajax_nopriv_check_existing_business_review', 'check_existing_business_review_handler');

function check_existing_business_review_handler() {
if (!is_user_logged_in()) {
wp_send_json_error("Not logged in");
return;
}

$user_login = isset($_POST['user_login']) ? trim($_POST['user_login']) : '';
$platform_url = isset($_POST['platform_url']) ? trim($_POST['platform_url']) : '';

if (empty($user_login) || empty($platform_url)) {
wp_send_json_error("Missing required parameters");
return;
}

try {
$conn = getConnection();

// Check for existing reviews
$stmt = $conn->prepare("
SELECT id 
FROM reviews 
WHERE user_login = ? 
AND google_maps_url = ?
LIMIT 1
");

$stmt->execute([$user_login, $platform_url]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

wp_send_json_success([
'exists' => !empty($result)
]);

} catch (Exception $e) {
error_log("Error checking existing business review: " . $e->getMessage());
wp_send_json_error("Database error: " . $e->getMessage());
}
}
add_action('wp_enqueue_scripts', 'feedback_form_assets');



// Add a new AJAX endpoint to check daily limit
add_action('wp_ajax_check_daily_limit', 'check_daily_limit_handler');
add_action('wp_ajax_nopriv_check_daily_limit', 'check_daily_limit_handler');

function check_daily_limit_handler() {
if (!is_user_logged_in()) {
wp_send_json_error("Not logged in");
return;
}

$current_user = wp_get_current_user();
$userLogin = $current_user->user_login;

try {
$conn = getConnection();

// Count reviews submitted in the last 24 hours
$stmt = $conn->prepare("
SELECT COUNT(*) AS review_count 
FROM reviews 
WHERE user_login = ? 
AND review_date >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
");
$stmt->execute([$userLogin]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

$count = $result && isset($result['review_count']) ? (int)$result['review_count'] : 0;

// Debug log the actual count
error_log("AJAX check: User {$userLogin} has written {$count} reviews in the last 24 hours");

if ($count >= 3) {
wp_send_json_error("Dosáhli jste denního limitu 3 recenzí za 24 hodin.");
} else {
wp_send_json_success([
'count' => $count,
'remaining' => 3 - $count
]);
}

} catch (Exception $e) {
error_log("Error in check_daily_limit_handler: " . $e->getMessage());
wp_send_json_error("Database error: " . $e->getMessage());
}
}
// ----------------------------------------------------
// 5) Create the shortcode for the feedback form
// ----------------------------------------------------
function feedback_form_shortcode() {
ob_start();
?>
<!-- Your HTML code remains unchanged -->

<div id="um-debugging"></div>
<p>Porno</p> 
<section id="feedback-form-container">

<button id="openReviewBtn" style="padding: 10px 20px; font-size: 16px;">Napsat recenzi!!</button>

<!-- Loader shown while we fetch data from Airtable -->
<div id="loaderContainer" class="loader-container" aria-label="Načítání obsahu. Prosím čekejte.">
<div class="loader"></div>
</div>

<!-- Main Modal -->
<div class="modal" role="dialog" aria-modal="true" aria-labelledby="feedbackDialogTitle">
<div class="modal-header">
<h2 id="feedbackDialogTitle">Sestavení zpětné vazby pro podnik</h2>
<div id="statusBadge">Načítání...</div>
</div>

<div class="modal-body">
<div class="feedback-question">
Chcete odeslat pozitivní nebo negativní feedback?
</div>

<!-- Positive/Negative Toggle -->
<div class="toggle-container">
<div class="toggle-buttons" role="group" aria-label="Výběr typu feedbacku">
<button id="positiveBtn" class="toggle-button active" aria-pressed="true">POZITIVNÍ</button>
<button id="negativeBtn" class="toggle-button" aria-pressed="false">NEGATIVNÍ</button>
</div>
</div>

<!-- Positive Feedback Form -->
<div id="positiveForm">
<div class="options-container">
<div class="options-column">
<div class="options-title required">Co se Vám líbilo (vyberte alespoň dvě)</div>
<div id="positiveOptionsGroup" class="checkbox-group" aria-label="Pozitivní možnosti">
<div class="checkbox-item">
<input type="checkbox" id="positive-loading" disabled>
<label for="positive-loading">Načítání možností...</label>
</div>
</div>
</div>

<div class="options-column">
<div class="options-title">Co se Vám nelíbilo (dobrovolné)</div>
<div id="negativeOptionsGroup" class="checkbox-group" aria-label="Negativní možnosti">
<div class="checkbox-item">
<input type="checkbox" id="negative-loading" disabled>
<label for="negative-loading">Načítání možností...</label>
</div>
</div>
</div>
</div>

<!-- Shrnutí výběru -->
<div class="selection-summary">
<div class="summary-title">Vybrané možnosti:</div>
<div class="positive-summary">
<span>Pozitivní:</span> <span id="positiveSummary">-</span>
</div>
<div class="negative-summary" style="display: none;">
<span>Negativní:</span> <span id="negativeSummary">-</span>
</div>
</div>

<!-- AI Generated Text Section -->
<div class="text-area">
<div class="text-area-title">AI generovaný text:</div>
<p id="generatedText" class="text-content">
Vyberte možnosti výše a klikněte na 'GENEROVAT JINÝ TEXT' pro vytvoření recenze.
</p>
<div id="generatingOverlay" class="generating-overlay" aria-label="Generuji text...">
<div class="loader"></div>
<div class="generating-text">Generuji text...</div>
</div>
</div>

<!-- Action Buttons for Positive Form -->
<div class="action-buttons">
<button id="publishBtn" class="btn btn-primary" disabled>
<span>✓</span> ZVEŘEJNIT RECENZI
</button>
<button id="regenerateBtn" class="btn btn-secondary">
<span>🔄</span> GENEROVAT JINÝ TEXT
</button>
<button id="cancelBtn" class="btn btn-danger">
<span>✕</span> ZRUŠIT FEEDBACK
</button>
</div>
</div>

<!-- Negative Feedback Form (Hidden by Default) -->
<div id="negativeForm" style="display: none;">
<div class="feedback-question">
Jakou máte zkušenost s tímto podnikem (alespoň 500 slov)?
</div>

<!-- Example form submission using Formspree -->
<form id="formspreeForm" class="formspree-form" action="https://formspree.io/f/mvgzebye" method="POST">


<div class="textarea-container">
<textarea 
id="messageInput" 
name="message" 
class="input-area" 
placeholder="Popište svou zkušenost..." 
aria-label="Popište svou negativní zkušenost alespoň 500 slovy"
></textarea>
<div id="formCounter">0 / 500</div>
</div>

<div class="action-buttons">
<button type="submit" id="submitFormBtn" class="btn btn-primary" disabled>
<span>✓</span> ODESLAT FEEDBACK
</button>
<button type="button" id="cancelFormBtn" class="btn btn-danger">
<span>✕</span> ZRUŠIT FEEDBACK
</button>
</div>
</form>
</div>
</div>
</div>

<!-- 1) Nový modal: "Otevření odkazu pro recenzi" -->
<div id="openLinkModal" class="confirm-modal" role="dialog" aria-modal="true">
<div class="confirm-content">
<div class="confirm-title">Otevření odkazu pro recenzi</div>
<p>Právě se otevřela nová karta s místem pro recenzi.</p>
<p>Text recenze je zkopírovaný ve schránce. Vložte ho tam.</p>
<p>Pokud jste připraveni, pokračujte níže.</p>
<p id="reviewLink" style="margin: 10px 0; font-size:14px; word-wrap:break-word;"></p>
<div id="aiTextPreview" style="margin: 10px 0; font-size:14px; background:#f9f9f9; padding:10px; border-radius:5px;"></div>


<div class="confirm-buttons">
<button id="openLinkModalContinueBtn" class="btn btn-primary">Pokračovat</button>
<button id="openLinkModalCloseBtn" class="btn btn-secondary">Zavřít</button>
</div>
</div>
</div>

<!-- 2) Druhý modal: "Napsal/a jste recenzi?" -->
<div 
id="confirmModal" 
class="confirm-modal" 
role="dialog" 
aria-modal="true"
>
<div class="confirm-content">
<div 
id="confirmModalTitle" 
class="confirm-title"
>
Napsal/a jste recenzi?
</div>
<div class="confirm-buttons">
<button id="confirmYesBtn" class="btn btn-primary">Ano</button>
<button id="confirmNoBtn" class="btn btn-secondary">Ne</button>
</div>
</div>
</div>

<!-- Success Overlay -->
<div id="successOverlay">
<svg width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="#00BFA5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
<polyline points="22 4 12 14.01 9 11.01"></polyline>
</svg>
<p>Feedback úspěšně odeslán!</p>
<p style="font-size:14px; color:#666;">Text byl zkopírován do schránky</p>
<div style="margin-top:20px;">
<button id="successCloseBtn" class="btn btn-primary" style="padding: 8px 20px; border-radius: 20px;">Zavřít</button>
</div>
</div>

<!-- Session Warning -->


<!-- Toast Notification -->
<div id="toast" class="toast" role="status" aria-live="polite"></div>

<!-- Copy Button Template (if needed) -->
<template id="copyBtnTemplate">
<button class="copy-btn" aria-label="Zkopírovat text do schránky">
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
<rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
<path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"></path>
</svg>
</button>
</template>

</section>
<?php
return ob_get_clean();
}
add_shortcode('feedback_form', 'feedback_form_shortcode');
?>