(function($) {
  /*********************************************************
   *               Global Configuration & Data
   *********************************************************/
  // Backend Logic Configuration
  const MAX_RETRIES = 3;
  const RETRY_DELAY = 1000;
  const ASSIGNMENT_CHECK_INTERVAL = 60000; // 1 minute
  const ASSIGNMENT_MAX_IDLE_TIME = 10 * 60000; // 30 minutes
  const HEARTBEAT_INTERVAL = 120000; // 2 minutes
  const SESSION_ID = generateUniqueId();
  
  let assignmentCheckTimer;
  let heartbeatTimer;
  let lastActivityTimestamp;
  
  // Airtable configuration
  const airtableApiKey = "patk8IhaVsT23lzkX.a0bcbcc0b7b2ced435c4b843a0fc52660f68cfb20f6d1bfd50a6a1ff7b901b6d";
  const airtableBaseId = "apphpjWQemBVF3uJc";
  const airtableTableId = "tblV2HSxR3Aecvv74";
  
  // OpenAI configuration
  const OPENAI_API_KEY = "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";
  
  // Constants for statuses in Airtable
  const STATUS = {
    ORDERED: "Ordered",
    ASSIGNED: "Assigned",
    AWAITING_VERIFICATION: "Awaiting Verification",
    COMPLETED: "Completed",
    PAID_OUT: "Paid out",
    UNASSIGNED: "Unassigned"
  };
  
  // Field mappings for Airtable (make sure these match your column names exactly!)
  const FIELD_MAPPINGS = {
  reviewId: "Review ID",
  parentOrder: "Parent Order",
  gender: "Gender",
  reviewStatus: "Review Status",
  descriptionName: "Description Name",
  platformUrl: "Platform URL",
  reviewText: "Review Text",
  specificRequest: "Specific Request (from Parent Order)",
  
  // Reviewer & Dates:
  assignmentReviewer: "Assigment reviewer",  // Will be set to user_login
  reviewerUsername: "Reviewer username",       // Will be set to user_login
  writtenDate: "Written Date",
  writtenDateDashboard: "Written date dashboard",
  assignedDate: "Assigned date",
  completionDate: "Completion date",
  
  // Other fields:
  options: "options",
  userUrl: "userUrl",  // Will be set to the meta data value from google-review-profile-link
  
  // Ultimate Member metadata fields (if used elsewhere)
  umGoogleUrl: "google-review-profile-link",
  umUsername: "user_login",
  umName: "first_name",
  
  // Reviewer tracking fields (if applicable)
  reviewerReviewsCompleted: "Reviewer reviews completed",
  reviewerReviewsInProgress: "Reviewer reviews in progress",
  reviewerReviewsPending: "Reviewer reviews pending",
  reviewerReviewsWaiting: "Reviewer Reviews Waiting",
  
  // Additional field if needed
  matakey: "Matakey Info"
};

  

  // Local variables
  let loadedReviews = [];         // fallback reviews
  let positiveOptions = {};       // loaded from Airtable
  const FIXED_NEGATIVE_OPTIONS = [
    "Personál nebyl dostatečně vstřícný",
    "Čekací doba byla příliš dlouhá",
    "Ceny jsou vyšší než by se dalo očekávat",
    "Prostředí by mohlo být čistější",
    "Jídlo neodpovídalo inzerované kvalitě"
  ];

  let currentBusiness = "";
  let currentPlatformUrl = "";
  let currentSpecificRequest = "";
  let currentRecordId = "";
  let currentGender = "any";

  // Base prompt for AI
  const basePrompt = "Napiš pozitivní recenzi podniku v češtině. Recenze by měla být přibližně 2-3 věty dlouhá a znít přirozeně. Používej jednoduchou, přátelskou a upřímnou češtinu. Zahrň tyto pozitivní body: ";

  // Session management
  let sessionTimer;
  let warningTimer;
  const SESSION_TIMEOUT = 15 * 60 * 1000; 
  const WARNING_BEFORE_TIMEOUT = 2 * 60 * 1000; 

  // Add this to your script.js file, near the beginning of the document.ready function:
 
// Hide loader on page load
$("#loaderContainer").hide();

// Modify your showLoader and hideLoader functions (if they exist)
function showLoader() {
  $("#loaderContainer").addClass('active').show();
}

function hideLoader() {
  $("#loaderContainer").removeClass('active').hide();
}

// Make sure any time you want to show the loader, you use:
// showLoader();
// And when you want to hide it:
// hideLoader();
  jQuery(document).ready(function($) {
    // Setup global error handling
    $(document).ready(function() {
      $("#testButton").click(function() {
          addMySQLRecord('testovaciUzivatel', 'https://example.com/platform');
      });
  });
    umDebugging();
    setupErrorHandling();
    
    // Event listener for the "Napsat recenzi" button
    // Modify the click handler for the "Napsat recenzi" button
$("#openReviewBtn").click(function() {
  // Check review count first before showing anything
  showLoader();
  
  $.ajax({
    url: feedback_form_ajax.ajax_url,
    type: 'POST',
    data: {
      action: 'get_user_review_count'
    },
    success: function(response) {
      if (response.success) {
        const data = response.data;
        
        if (data.limit_reached) {
          hideLoader();
          showToast("Dosáhli jste denního limitu 3 recenzí za 24 hodin.", "error");
          return;
        }
        
        if (data.remaining < 3) {
          // Show warning about remaining reviews
          showToast(`Můžete napsat ještě ${data.remaining} ${data.remaining === 1 ? 'recenzi' : (data.remaining >= 2 && data.remaining <= 4 ? 'recenze' : 'recenzí')} dnes.`, "warning", 5000);
        }
        
        // Continue with showing the modal and loading data
        $(".modal").fadeIn();
        loadData();
        resetForm();
        startSessionTimer();
      } else {
        hideLoader();
        showToast("Chyba při kontrole počtu recenzí", "error");
      }
    },
    error: function() {
      hideLoader();
      showToast("Chyba při kontrole počtu recenzí", "error");
      
      // Fallback - still show the form in case of error
      $(".modal").fadeIn();
      loadData();
      resetForm();
      startSessionTimer();
    }
  });
});

    // Switch between positive/negative forms
    $("#positiveBtn").click(function() {
      if (currentRecordId) updateAssignmentActivity();
      $(this).addClass("active").attr("aria-pressed", "true");
      $("#negativeBtn").removeClass("active").attr("aria-pressed", "false");
      $("#positiveForm").show();
      $("#negativeForm").hide();
    });
    
    $("#negativeBtn").click(function() {
      if (currentRecordId) updateAssignmentActivity();
      $(this).addClass("active").attr("aria-pressed", "true");
      $("#positiveBtn").removeClass("active").attr("aria-pressed", "false");
      $("#positiveForm").hide();
      $("#negativeForm").show();
    });

    // Character counting for negative form
    $("#messageInput").on("input", function() {
      if (currentRecordId) updateAssignmentActivity();
      const textLength = $(this).val().length; 
      $("#formCounter").text(textLength + " / 500");
      
      if (textLength >= 500) {
        $("#submitFormBtn").prop("disabled", false);
      } else {
        $("#submitFormBtn").prop("disabled", true);
      }
    });

    // Button: Regenerate AI text
    $("#regenerateBtn").click(function() {
      if (currentRecordId) updateAssignmentActivity();
      generateAIReview();
    });

    // Button: Publish => opens link + copies text => show #openLinkModal
    $("#publishBtn").click(function() {
      if (currentRecordId) updateAssignmentActivity();
      
      const reviewText = $("#generatedText").text();
      if (!reviewText || reviewText.includes("Vyberte možnosti výše")) {
        showToast("Nejdříve vygenerujte text recenze", "error");
        return;
      }

      // 1) Open link
      if (currentPlatformUrl) {
        try {
          window.open(currentPlatformUrl, "_blank");
        } catch(e) {
          console.warn("Nepodařilo se otevřít URL přímo:", e);
          logAction("openPlatformUrl", "error", { url: currentPlatformUrl, error: e.toString() });
        }
      } else {
        showToast("Nebyl nalezen odkaz pro recenzi.", "error");
        return;
      }

      // 2) Copy text
      try {
        const tempEl = document.createElement("textarea");
        tempEl.value = reviewText;
        document.body.appendChild(tempEl);
        tempEl.select();
        document.execCommand("copy");
        document.body.removeChild(tempEl);
        showToast("Text recenze zkopírován", "success");
        
        // Save draft state with generated text
        saveDraftState({
          generatedText: reviewText
        });
        
      } catch (err) {
        console.warn("Kopírování se nezdařilo:", err);
        logAction("copyReviewText", "error", { error: err.toString() });
      }

      // Show link & preview
      $("#reviewLink").html(`
        Pokud se odkaz neotevřel, otevřete prosím ručně: 
        <a href="${currentPlatformUrl}" target="_blank">${currentPlatformUrl}</a>
      `);

      $("#aiTextPreview").text(reviewText);

      // 3) Show openLinkModal
      $("#openLinkModal").css("display", "flex");
    });

    // openLinkModal => "Continue" => hide openLinkModal => show confirmModal
    $("#openLinkModalContinueBtn").click(function() {
      if (currentRecordId) updateAssignmentActivity();
      $("#openLinkModal").fadeOut();
      $("#confirmModal").css("display", "flex");
    });
    
    // openLinkModal => "Close"
    $("#openLinkModalCloseBtn").click(function() {
      if (currentRecordId) updateAssignmentActivity();
      $("#openLinkModal").fadeOut();
    });

    // confirmModal => "Yes" => update status to AWAITING_VERIFICATION
    // Confirm modal => "Yes"
    
    function handleConfirmYesClick() {
      if (currentRecordId) updateAssignmentActivity();
      $("#confirmModal").fadeOut();
      $("#loaderContainer").show();
  
      // Check daily limit first with enhanced info
      $.ajax({
        url: feedback_form_ajax.ajax_url,
        type: 'POST',
        data: {
          action: 'get_user_review_count'
        },
        success: function(response) {
          if (response.success && !response.data.limit_reached) {
            // Continue with submission
            submitReview();
          } else {
            hideLoader();
            showToast("Dosáhli jste denního limitu 3 recenzí za 24 hodin.", "error");
            setTimeout(() => window.location.reload(), 2000);
          }
        },
        error: function() {
          // If error, still proceed but log warning
          console.warn("Could not check review limit, proceeding anyway");
          submitReview();
        }
      });
      
      function submitReview() {
          const reviewText = $("#generatedText").text() || "";
          const today = new Date().toISOString().split("T")[0];
  
          // Get user metadata
          const userData = getUserUltimateMetadata();
          console.log("User data for Airtable update:", userData);
  
          // Build fields to update
          const fieldsToUpdate = {
              [FIELD_MAPPINGS.reviewStatus]: STATUS.AWAITING_VERIFICATION,
              [FIELD_MAPPINGS.reviewText]: reviewText,
              [FIELD_MAPPINGS.writtenDate]: today,
              [FIELD_MAPPINGS.writtenDateDashboard]: today,
              [FIELD_MAPPINGS.completionDate]: today
          };
  
          if (userData) {
              fieldsToUpdate[FIELD_MAPPINGS.assignmentReviewer] = userData.user_login;
              fieldsToUpdate[FIELD_MAPPINGS.reviewerUsername] = userData.user_login;
  
              if (userData.googleUrl) {
                  fieldsToUpdate[FIELD_MAPPINGS.userUrl] = userData.googleUrl;
                  console.log("Setting userUrl field to:", userData.googleUrl);
              } else {
                  console.warn("Google review profile link not found in user data");
              }
          }
  
          console.log("Fields being sent to Airtable:", fieldsToUpdate);
  
          safeAirtableUpdate(currentRecordId, fieldsToUpdate)
              .then(() => {
                  // After successful Airtable update, also write to the MySQL database
                  const userData = getUserUltimateMetadata();
                  const reviewText = $("#generatedText").text() || "";
                  
                  // Send to WordPress AJAX endpoint
                  $.ajax({
                      url: feedback_form_ajax.ajax_url,
                      type: 'POST',
                      data: {
                          action: 'confirm_review',
                          platform_url: currentPlatformUrl,
                          review_text: reviewText
                      },
                      beforeSend: function() {
                          console.log("Sending data to database:", {
                              platform_url: currentPlatformUrl,
                              review_text: reviewText
                          });
                      },
                      success: function(response) {
                          console.log("Database response:", response);
                          // Continue with your existing success code
                          hideLoader();
                          clearAssignmentState();
                          $("#successOverlay").fadeIn();
                          setTimeout(() => {
                              window.location.reload();
                          }, 1500);
                      },
                      error: function(error) {
                          console.error("Error updating database:", error);
                          // Still continue with the flow, as Airtable was updated
                          hideLoader();
                          clearAssignmentState();
                          $("#successOverlay").fadeIn();
                          setTimeout(() => {
                              window.location.reload();
                          }, 1500);
                      }
                  });
              })
              .catch((err) => {
                  // Your existing error handling code
                  console.error("Error updating Airtable:", err);
                  hideLoader();
                  if (confirm("Došlo k chybě při ukládání. Chcete záznam uvolnit pro ostatní?")) {
                      safeAirtableUpdate(currentRecordId, {
                          [FIELD_MAPPINGS.reviewStatus]: STATUS.UNASSIGNED
                      })
                          .then(() => {
                              clearAssignmentState();
                              showToast("Záznam uvolněn", "info");
                              setTimeout(() => window.location.reload(), 1500);
                          })
                          .catch(e => {
                              console.error("Failed to release record:", e);
                              showToast("Nepodařilo se uvolnit záznam", "error");
                          });
                  }
              });
      }
  }

// Bind the new consolidated function to the button
$("#confirmYesBtn").click(handleConfirmYesClick);



    // confirmModal => "No"
    $("#confirmNoBtn").click(function() {
      if (currentRecordId) updateAssignmentActivity();
      $("#confirmModal").fadeOut();
    });

    // successOverlay => "Zavřít"
    $("#successCloseBtn").click(function() {
      $("#successOverlay").fadeOut();
      window.location.reload();
    });
    
    // Cancel button in Positive form
    $("#cancelBtn").click(function() {
      if (confirm("Opravdu chcete zrušit tento feedback?")) {
        $("#loaderContainer").show();
        
        safeAirtableUpdate(currentRecordId, { 
          [FIELD_MAPPINGS.reviewStatus]: STATUS.UNASSIGNED 
        })
          .then(() => {
            clearAssignmentState();
            showToast("Feedback zrušen", "info");
            
            setTimeout(() => {
              window.location.reload();
            }, 1000);
          })
          .catch((e) => {
            console.error("Chyba při zrušení:", e);
            showToast("Nelze změnit stav na Unassigned", "error");
            hideLoader();
          });
      }
    });

    // Cancel button in Negative form
    $("#cancelFormBtn").click(function(e) {
      e.preventDefault();
      if (confirm("Opravdu chcete zrušit tento feedback?")) {
        $("#loaderContainer").show();
        safeAirtableUpdate(currentRecordId, { 
          [FIELD_MAPPINGS.reviewStatus]: STATUS.UNASSIGNED 
        })
          .then(() => {
            clearAssignmentState();
            showToast("Feedback zrušen", "info");
            
            // Reset text area
            $("#messageInput").val("");
            $("#formCounter").text("0 / 500");
            $("#submitFormBtn").prop("disabled", true);

            setTimeout(() => {
              window.location.reload();
            }, 1000);
          })
          .catch((e) => {
            console.error("Chyba:", e);
            showToast("Nelze změnit stav na Unassigned", "error");
            hideLoader();
          });
      }
    });

    // Submit negative => must have 500 chars
    $("#formspreeForm").submit(function(e) {
      e.preventDefault();
      
      if ($("#messageInput").val().length < 500) {
        showToast("Prosím napište alespoň 500 znaků", "error");
        return false;
      }
      
      $("#loaderContainer").show();
      
      // Return to 'Unassigned'
      safeAirtableUpdate(currentRecordId, { 
        [FIELD_MAPPINGS.reviewStatus]: STATUS.UNASSIGNED 
      })
        .then(function() {
          clearAssignmentState();
          showToast("Feedback odeslán", "success");
          
          // Submit form to Formspree
          const form = $("#formspreeForm")[0];
          const formData = new FormData(form);
          
          fetch(form.action, {
            method: form.method,
            body: formData,
            headers: {
              'Accept': 'application/json'
            }
          })
          .then(response => {
            if (response.ok) {
              $("#successOverlay").fadeIn();
              
              setTimeout(() => {
                window.location.reload();
              }, 1500);
            } else {
              throw new Error("Network response was not ok");
            }
          })
          .catch(error => {
            console.error("Error submitting form:", error);
            showToast("Chyba při odesílání formuláře", "error");
            hideLoader();
          });
        })
        .catch(function(error) {
          console.error("Error updating Airtable:", error);
          showToast("Chyba při nastavení stavu v Airtable", "error");
          hideLoader();
        });
    });

    // Online/offline listeners
    window.addEventListener("online", () => {
      showToast("Připojení obnoveno", "success");
      logAction("network", "online");
    });
    window.addEventListener("offline", () => {
      showToast("Odpojili jste se od internetu", "error");
      logAction("network", "offline");
    });

    // Warn on unload
    window.addEventListener("beforeunload", function(e) {
      const hasCheckedOptions = $(".positive-option:checked").length > 0 || $(".negative-option:checked").length > 0;
      
      // Save draft before unload
      if (hasCheckedOptions || $("#generatedText").text().length > 0) {
        saveDraftState({
          generatedText: $("#generatedText").text()
        });
      }
      
      // Mark as orphaned using beacon API if assigned
      if (currentRecordId) {
        const data = JSON.stringify({
          id: currentRecordId,
          status: STATUS.UNASSIGNED
        });
        
        try {
          navigator.sendBeacon("/api/release-record", data);
        } catch (err) {
          // Fallback for older browsers
          fetch("/api/release-record", {
            method: "POST",
            body: data,
            keepalive: true
          }).catch(e => console.error("Error releasing record:", e));
        }
      }
      
      if (hasCheckedOptions) {
        e.preventDefault();
        e.returnValue = "Máte rozpracovaný feedback. Chcete opravdu odejít?";
        return e.returnValue;
      }
    });

    // Track activity only if a record is assigned
    jQuery(document).on("click keypress mousemove", function() {
      if (currentRecordId) { 
        resetSessionTimer();
        updateAssignmentActivity();
      }
    });
  });



  

  /*********************************************************
   *              Load & Assign Record Logic
   *********************************************************/
  function loadData() {
    checkForOrphanedRecords();
    $("#loaderContainer").show();
    
    fetchAirtableRecords()
      .then(response => {
        if (response.records && response.records.length > 0) {
          const unassignedRecords = processUnassignedRecords(response.records);
          if (unassignedRecords.length === 0) {
            // No unassigned => hide loader & close modal
            hideLoader();
            $(".modal").fadeOut();
            showToast("Momentálně nejsou k dispozici žádné recenze k napsání.", "info");
            return Promise.reject(new Error("No unassigned records found"));
          }
          // We have unassigned => assign one
          return assignRandomRecord(response.records);
        } else {
          // No records at all
          hideLoader();
          $(".modal").fadeOut();
          showToast("Nenalezeny žádné záznamy k recenzi.", "error");
          return Promise.reject(new Error("No records found"));
        }
      })
      .then(() => {
        hideLoader();
        tryRestoreDraft();
        startHeartbeat();
        setupDeadmansSwitch();
      })
      // In your .catch() block where this error is handled (around line 635)
      .catch(error => {
        // Make sure we hide the loader on error
        hideLoader();
        
        if (error.message === "User already wrote a review for this business") {
          // Skip the handleError call for this specific message
          showToast("Již jste psali recenzi pro tento podnik.", "info");
          $(".modal").fadeOut();
        } else if (error.message === "Daily review limit reached") {
          showToast("Dosáhli jste denního limitu 3 recenzí za 24 hodin.", "warning");
          $(".modal").fadeOut();
        } else if (error.message === "No unassigned records found") {
          showToast("Momentálně nejsou k dispozici žádné recenze k napsání.", "info");
        } else {
          handleError("Failed to load data", { error: error.toString() });
        }
        $(".modal").fadeOut();
      });
      
  }

  

  // Fetch records from Airtable with retry mechanism
  function fetchAirtableRecords(attempt = 1) {
    return new Promise((resolve, reject) => {
      $.ajax({
        url: `https://api.airtable.com/v0/${airtableBaseId}/${airtableTableId}?pageSize=100&view=Grid%20view`,
        method: "GET",
        headers: { "Authorization": `Bearer ${airtableApiKey}` },
        timeout: 30000,
        success: function(response) {
          logAction("fetchAirtableRecords", "success", { recordCount: response.records?.length || 0 });
          resolve(response);
        },
        error: function(xhr, status, error) {
          logAction("fetchAirtableRecords", "error", { attempt, status, error });
          if (attempt < MAX_RETRIES) {
            const delay = RETRY_DELAY * Math.pow(2, attempt - 1);
            setTimeout(() => {
              fetchAirtableRecords(attempt + 1)
                .then(resolve)
                .catch(reject);
            }, delay);
          } else {
            reject(new Error(`Failed to fetch Airtable records after ${MAX_RETRIES} attempts: ${error}`));
          }
        }
      });
    });
  }

  // Process records to find unassigned
  function processUnassignedRecords(records) {
    if (!Array.isArray(records)) {
      logAction("processUnassignedRecords", "error", { 
        message: "Records is not an array", 
        value: records 
      });
      return [];
    }
    return records.filter(r => 
      r.fields && r.fields[FIELD_MAPPINGS.reviewStatus] === STATUS.UNASSIGNED
    );
  }

  // Assign a random record from unassigned
  function assignRandomRecord(records) {
    const unassignedRecords = processUnassignedRecords(records);
    if (unassignedRecords.length === 0) {
      showToast("Žádný záznam ve stavu 'Unassigned' nebyl nalezen.", "info");
      hideLoader();
      return Promise.reject(new Error("No unassigned records found"));
    }
    const randomIndex = Math.floor(Math.random() * unassignedRecords.length);
    const selectedRecord = unassignedRecords[randomIndex];
    return processSelectedRecord(selectedRecord);
    
  }

 // Process a selected record for assignment
// Process a selected record for assignment
function processSelectedRecord(record) {
  if (!record || !record.id) {
    return Promise.reject(new Error("Invalid record"));
  }


  
  currentRecordId = record.id;
  extractOptions(record);
  
  const fields = record.fields;
  if (fields[FIELD_MAPPINGS.descriptionName]) {
    currentBusiness = fields[FIELD_MAPPINGS.descriptionName];
    $(".modal-header h2").text(`Sestavení zpětné vazby pro podnik: ${currentBusiness}`);
  }
  if (fields[FIELD_MAPPINGS.platformUrl]) {
    let url = fields[FIELD_MAPPINGS.platformUrl];
    if (!url.startsWith("http")) url = "https://" + url;
    currentPlatformUrl = url;
  } else {
    currentPlatformUrl = "";
  }
  if (fields[FIELD_MAPPINGS.specificRequest]) {
    currentSpecificRequest = fields[FIELD_MAPPINGS.specificRequest];
  }
  if (fields[FIELD_MAPPINGS.gender] && typeof fields[FIELD_MAPPINGS.gender] === "string") {
    currentGender = fields[FIELD_MAPPINGS.gender].toLowerCase();
  } else {
    currentGender = "any";
  }
  // Save parent order value for later use (if available)
  if (fields[FIELD_MAPPINGS.parentOrder]) {
    currentParentOrder = fields[FIELD_MAPPINGS.parentOrder];
  } else {
    currentParentOrder = "";
  }
  
  // Retrieve user metadata for gender and review check
  const userData = getUserUltimateMetadata();

  console.log("User metadata:", userData);
  console.log("Current gender:", currentGender);
  
  // Check user's eligibility based on gender
// Check user's eligibility based on gender
if (currentGender !== "any" && userData && userData.gender) {
  // Handle complex gender data structure (it might be an object or a string)
  let userGenderValue;
  
  // If gender is an object with a "Muž" or "Žena" property
  if (typeof userData.gender === 'object') {
    if ('Muž' in userData.gender) {
      userGenderValue = 'muž';
    } else if ('Žena' in userData.gender) {
      userGenderValue = 'žena';
    } else {
      userGenderValue = 'any'; // Default if we can't determine
    }
  } else {
    // If gender is provided as a string
    userGenderValue = String(userData.gender).toLowerCase();
  }
  
  // Normalize gender values
  let normalizedUserGender = userGenderValue;
  if (userGenderValue === "muž" || userGenderValue === "muz") {
    normalizedUserGender = "male";
  } else if (userGenderValue === "žena" || userGenderValue === "zena") {
    normalizedUserGender = "female";
  }
  
  let normalizedReviewGender = currentGender;
  if (currentGender === "muž" || currentGender === "muz") {
    normalizedReviewGender = "male";
  } else if (currentGender === "žena" || currentGender === "zena") {
    normalizedReviewGender = "female";
  }
  
  // Check if genders match
  if (normalizedUserGender !== normalizedReviewGender) {
    showToast(`Tento záznam je určen pouze pro ${currentGender === "male" ? "muže" : "ženu"}.`, "error");
    return Promise.reject(new Error("User gender does not match record requirement"));
  }
}
  
  if (!userData || !userData.user_login) {
    showToast("Uživatelské údaje nejsou k dispozici.", "error");
    return Promise.reject(new Error("User data not available"));
  }
  
  // First check if the user has already written a review for this business
  return checkExistingBusinessReview(userData.user_login, currentPlatformUrl)
    .then(hasExistingReview => {
      if (hasExistingReview) {
        showToast("Již jste psali recenzi pro tento podnik.", "error");
        return Promise.reject(new Error("User already wrote a review for this business"));
      }
      
      // Then check parent order if applicable
      if (currentParentOrder) {
        return checkUserReviewForParentOrder(currentParentOrder, userData.user_login)
          .then(exists => {
            if (exists) {
              showToast("Už jste napsali recenzi pro tento parent order.", "error");
              return Promise.reject(new Error("User already wrote a review for this parent order"));
            } else {
              // Finally check daily review limit
              return checkDailyReviewLimit(userData.user_login)
                .then(hasReachedLimit => {
                  if (hasReachedLimit) {
                    showToast("Dosáhli jste denního limitu 3 recenzí za 24 hodin.", "error");
                    return Promise.reject(new Error("Daily review limit reached"));
                  }
                  
                  // All checks passed - assign the review
                  saveAssignmentState(record.id);
                  const today = new Date().toISOString().split("T")[0];
                  return safeAirtableUpdate(currentRecordId, {
                    [FIELD_MAPPINGS.reviewStatus]: STATUS.ASSIGNED,
                    [FIELD_MAPPINGS.assignedDate]: today
                  })
                    .then(() => {
                      showToast("Záznam přidělen", "success");
                      populateOptions();
                      return record;
                    });
                });
            }
          });
      } else {
        // No parent order, check daily limit and proceed
        return checkDailyReviewLimit(userData.user_login)
        .then(limitInfo => {
          if (limitInfo.limitReached) {
            showToast("Dosáhli jste denního limitu 3 recenzí za 24 hodin.", "error");
            return Promise.reject(new Error("Daily review limit reached"));
          }
          
          if (limitInfo.remaining < 3) {
            // Show warning about remaining reviews
            showToast(`Můžete napsat ještě ${limitInfo.remaining} ${limitInfo.remaining === 1 ? 'recenzi' : (limitInfo.remaining >= 2 && limitInfo.remaining <= 4 ? 'recenze' : 'recenzí')} dnes.`, "warning", 5000);
          }
          
          // All checks passed - assign the review
          saveAssignmentState(record.id);
          const today = new Date().toISOString().split("T")[0];
          return safeAirtableUpdate(currentRecordId, {
            [FIELD_MAPPINGS.reviewStatus]: STATUS.ASSIGNED,
            [FIELD_MAPPINGS.assignedDate]: today
          })
            .then(() => {
              showToast("Záznam přidělen", "success");
              populateOptions();
              return record;
            });
        });
      }
    })
    .catch(err => {
      showToast(err.message, "error");
      return Promise.reject(err);
    });
}

// Function to check if user has already written a review for this business
function checkExistingBusinessReview(userLogin, platformUrl) {
if (!userLogin || !platformUrl) {
  return Promise.resolve(false);
}

return new Promise((resolve, reject) => {
  $.ajax({
    url: feedback_form_ajax.ajax_url,
    type: 'POST',
    data: {
      action: 'check_existing_business_review',
      user_login: userLogin,
      platform_url: platformUrl
    },
    success: function(response) {
      if (response.success) {
        resolve(response.data.exists); // true if review exists, false otherwise
      } else {
        console.warn("Error checking existing reviews:", response.data);
        resolve(false); // On error, default to allowing
      }
    },
    error: function(error) {
      console.error("AJAX error checking existing reviews:", error);
      resolve(false); // On error, default to allowing
    }
  });
});
}

// Function to check daily review limit via AJAX
// Enhanced function to check daily review limit via AJAX
function checkDailyReviewLimit(userLogin) {
  if (!userLogin) return Promise.resolve({ limitReached: false, count: 0, remaining: 3 });

  return new Promise((resolve, reject) => {
    $.ajax({
      url: feedback_form_ajax.ajax_url,
      type: 'POST',
      data: {
        action: 'get_user_review_count'
      },
      success: function(response) {
        if (response.success) {
          resolve({
            limitReached: response.data.limit_reached,
            count: response.data.count,
            remaining: response.data.remaining
          });
        } else {
          console.warn("Error checking review limit:", response.data);
          resolve({ limitReached: false, count: 0, remaining: 3 }); // Default to allowing
        }
      },
      error: function() {
        console.error("AJAX error checking review limit");
        resolve({ limitReached: false, count: 0, remaining: 3 }); // Default to allowing
      }
    });
  });
}



  

  






  // Extract options from record, handle fallback
  function extractOptions(record) {
    positiveOptions = {};
    const fields = record.fields;
    
    // If there's an "options" field with commas
    if (fields[FIELD_MAPPINGS.options]) {
      const optionsText = fields[FIELD_MAPPINGS.options];
      if (typeof optionsText === 'string' && optionsText.includes(',')) {
        const arr = optionsText.split(",").map(o => o.trim());
        arr.forEach((opt, i) => {
          if (i < 10 && opt) {
            positiveOptions[i+1] = opt;
          }
        });
      } 
      // If numeric
      else if (typeof optionsText === 'number' || (typeof optionsText === 'string' && !isNaN(optionsText))) {
        const num = parseInt(optionsText, 10);
        const fallbackOptions = [
          "Kvalita jídla", "Příjemný personál", "Dobrá cena", 
          "Příjemné prostředí", "Rychlá obsluha", "Chutné nápoje",
          "Dobrá lokalita", "Čistota", "Speciální nabídky", "Atmosféra"
        ];
        if (num >= 1 && num <= fallbackOptions.length) {
          positiveOptions[1] = fallbackOptions[num - 1];
        }
      }
    } 
    
    // If still empty => fallback
    if (Object.keys(positiveOptions).length === 0) {
      const fallback = ["Personál", "Jídlo", "Prostředí", "Atmosféra", "Servis"];
      fallback.forEach((option, i) => {
        positiveOptions[i+1] = option;
      });
    }
    
    return positiveOptions;
  }

  // Populate the UI with options
  function populateOptions() {
    $("#positiveOptionsGroup, #negativeOptionsGroup").empty();

    let hasPos = false;
    for (let i=1; i<=10; i++){
      if (positiveOptions[i]) {
        hasPos = true;
        $("#positiveOptionsGroup").append(`
          <div class="checkbox-item">
            <input type="checkbox" id="positive-${i}" class="positive-option">
            <label for="positive-${i}">${positiveOptions[i]}</label>
          </div>
        `);
      }
    }
    if (!hasPos) {
      const fallbackPos = ["Personál", "Jídlo", "Prostředí", "Atmosféra", "Servis"];
      fallbackPos.forEach((p, idx) => {
        $("#positiveOptionsGroup").append(`
          <div class="checkbox-item">
            <input type="checkbox" id="positive-${idx+1}" class="positive-option">
            <label for="positive-${idx+1}">${p}</label>
          </div>
        `);
      });
    }

    FIXED_NEGATIVE_OPTIONS.forEach((neg, idx) => {
      $("#negativeOptionsGroup").append(`
        <div class="checkbox-item">
          <input type="checkbox" id="negative-${idx+1}" class="negative-option">
          <label for="negative-${idx+1}">${neg}</label>
        </div>
      `);
    });

    $(".positive-option, .negative-option").change(function(){
      validateOptions();
      updateSelectionSummary();
    });
  }

  // Validate selected options to enable publish
  function validateOptions() {
    const count = $(".positive-option:checked").length;
    if(count >= 2) {
      $("#publishBtn").prop("disabled", false);
    } else {
      $("#publishBtn").prop("disabled", true);
    }
  }

  /*********************************************************
   *           Airtable Update Functions
   *********************************************************/
  
  // Safe update with retry
  function safeAirtableUpdate(recordId, fields, attempt = 1) {
    return new Promise((resolve, reject) => {
      if (!recordId) return reject(new Error("No record ID provided"));
      
      // Clean fields
      const cleanFields = {};
      Object.keys(fields).forEach(key => {
        if (fields[key] !== undefined && fields[key] !== null) {
          cleanFields[key] = fields[key];
        }
      });
      
      console.log(`Updating Airtable record ${recordId}, attempt ${attempt}`, cleanFields);
      
      $.ajax({
        url: `https://api.airtable.com/v0/${airtableBaseId}/${airtableTableId}/${recordId}`,
        method: "PATCH",
        headers: {
          "Authorization": `Bearer ${airtableApiKey}`,
          "Content-Type": "application/json"
        },
        data: JSON.stringify({ fields: cleanFields }),
        success: (res) => {
          console.log("Airtable update successful");
          resolve(res);
        },
        error: (xhr, status, error) => {
          console.error("Airtable update failed", {
            status: xhr.status,
            statusText: xhr.statusText,
            responseText: xhr.responseText
          });
          
          if (attempt < MAX_RETRIES) {
            setTimeout(() => {
              safeAirtableUpdate(recordId, cleanFields, attempt + 1)
                .then(resolve)
                .catch(reject);
            }, RETRY_DELAY * Math.pow(2, attempt - 1));
          } else {
            showToast("Nešlo uložit záznam do Airtable", "error");
            reject(new Error(`Failed to update Airtable record: ${xhr.statusText}`));
          }
        }
      });
    });
  }

  // Check record status
  function checkRecordStatus(recordId) {
    return new Promise((resolve, reject) => {
      if (!recordId) return reject(new Error("No record ID provided"));
      
      $.ajax({
        url: `https://api.airtable.com/v0/${airtableBaseId}/${airtableTableId}/${recordId}`,
        method: "GET",
        headers: { "Authorization": `Bearer ${airtableApiKey}` },
        success: (response) => {
          if (response && response.fields) {
            const status = response.fields[FIELD_MAPPINGS.reviewStatus];
            resolve(status);
          } else {
            reject(new Error("Invalid response format from Airtable"));
          }
        },
        error: (xhr) => {
          reject(new Error(`Failed to check record status: ${xhr.responseText}`));
        }
      });
    });
  }

  // Check and repair record if needed (KEEP ONE VERSION)
  // This version includes logs & toast
  function checkAndRepairRecord(recordId) {
    if (!recordId) return Promise.resolve();
    
    return checkRecordStatus(recordId)
      .then(status => {
        console.log(`Current record status: ${status}`);
        
        // If record is still in ASSIGNED, offer to release
        if (status === STATUS.ASSIGNED) {
          if (confirm("Došlo k chybě při ukládání. Chcete záznam uvolnit pro ostatní?")) {
            console.log("User confirmed releasing record");
            return safeAirtableUpdate(recordId, {
              [FIELD_MAPPINGS.reviewStatus]: STATUS.UNASSIGNED
            })
            .then(() => {
              showToast("Záznam byl uvolněn", "success");
              clearAssignmentState();
              setTimeout(() => {
                window.location.reload();
              }, 1500);
            })
            .catch(e => {
              console.error("Failed to release record:", e);
              showToast("Nepodařilo se uvolnit záznam", "error");
            });
          }
        } else {
          console.log(`Record is already in ${status} state, no repair needed`);
        }
      })
      .catch(err => {
        console.error("Failed to check record status:", err);
        showToast("Nepodařilo se ověřit stav záznamu", "error");
      });
  }

  /*********************************************************
   *           AI Review Generation Functions
   *********************************************************/
  async function generateAIReview() {
    $("#generatingOverlay").css("display", "flex");
    $("#publishBtn").prop("disabled", true);
    
    if (currentRecordId) updateAssignmentActivity();

    const selectedPos = [];
    $(".positive-option:checked").each(function(){
      const id = $(this).attr("id").replace("positive-","");
      selectedPos.push(positiveOptions[id] || $(this).next("label").text());
    });
    
    if(selectedPos.length < 2){
      $("#generatingOverlay").hide();
      $("#generatedText").text("Vyberte aspoň 2 pozitivní body");
      showToast("Vyberte aspoň 2 pozitivní body", "error");
      return;
    }
    
    const selectedNeg = [];
    $(".negative-option:checked").each(function(){
      selectedNeg.push($(this).next("label").text());
    });

    // Build prompt
    let prompt = basePrompt + selectedPos.join(", ");
    if(selectedNeg.length > 0){
      prompt += ". Zahrň i tyto body jako lehkou kritiku: " + selectedNeg.join(", ");
    }
    if (currentSpecificRequest) {
      prompt += ". " + currentSpecificRequest;
    }
    if (currentBusiness) {
      prompt += ". Jméno podniku: " + currentBusiness;
    }
    if (currentGender && currentGender !== "any") {
      prompt += `. Recenzi napiš z pohledu ${currentGender === "male" ? "muže" : "ženy"}.`;
    }
    
    // Save current state
    if (currentRecordId) {
      saveDraftState({
        positiveOptions: selectedPos,
        negativeOptions: selectedNeg,
        businessName: currentBusiness,
        prompt: prompt
      });
    }

    try {
      if(OPENAI_API_KEY && OPENAI_API_KEY !== "YOUR_OPENAI_API_KEY"){
        const reviewText = await generateWithOpenAI(prompt);
        if (reviewText) {
          $("#generatedText").text(reviewText);
          if (currentRecordId) saveDraftState({ generatedText: reviewText });
        } else {
          await generateFallbackReview();
        }
      } else {
        await generateFallbackReview();
      }
    } catch(err){
      logAction("generateAIReview", "error", { 
        error: err.toString(),
        prompt: prompt
      });
      await generateFallbackReview();
    } finally {
      $("#generatingOverlay").fadeOut();
      validateOptions();
      addCopyButton();
      $(".text-area").removeClass("success-animation").addClass("success-animation");
    }
  }

  // Call OpenAI
  function generateWithOpenAI(prompt) {
    return new Promise((resolve) => {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 30000); // 30 sec timeout
      
      fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${OPENAI_API_KEY}`
        },
        signal: controller.signal,
        body: JSON.stringify({
          model: "gpt-4.5-preview",
          messages: [
            { 
              role: "system", 
              content: "generujeě přirozeně znějící, lidské 5hvězdičkové recenze výhradně v češtině..." 
            },
            { role: "user", content: prompt }
          ],
          max_tokens: 200,
          temperature: 0.7
        })
      })
      .then(response => {
        clearTimeout(timeoutId);
        if (!response.ok) {
          throw new Error(`OpenAI API responded with status: ${response.status}`);
        }
        return response.json();
      })
      .then(data => {
        if(data.choices && data.choices[0] && data.choices[0].message){
          resolve(data.choices[0].message.content.trim());
        } else {
          logAction("generateWithOpenAI", "error", { 
            message: "Unexpected API response format", 
            data 
          });
          resolve(null);
        }
      })
      .catch(err => {
        clearTimeout(timeoutId);
        logAction("generateWithOpenAI", "error", { message: err.toString(), prompt });
        resolve(null); // triggers fallback
      });
    });
  }

  // Fallback review
  async function generateFallbackReview() {
    if(loadedReviews.length > 0){
      const valid = loadedReviews.filter(r => r.reviewText && r.reviewText.trim() !== "");
      if(valid.length > 0){
        const rnd = Math.floor(Math.random() * valid.length);
        $("#generatedText").text(valid[rnd].reviewText);
        return;
      }
    }
    
    const fallback = [
      "Byli jsme mile překvapeni kvalitou jídla i přístupem personálu. Moc se nám líbilo a rádi se vrátíme.",
      "Prostředí je krásné a personál usměvavý. Jídlo nám chutnalo a rádi doporučíme dalším.",
      "Skvělá obsluha, dobré ceny, útulné prostředí. Určitě stojí za návštěvu!"
    ];
    const r = Math.floor(Math.random() * fallback.length);
    $("#generatedText").text(fallback[r]);
  }

  /*********************************************************
   *          Session and State Management
   *********************************************************/
  function generateUniqueId() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      const r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }

  function saveDraftState(data) {
    if (!currentRecordId) return; 
    try {
      const state = {
        timestamp: Date.now(),
        recordId: currentRecordId,
        businessName: currentBusiness,
        platformUrl: currentPlatformUrl,
        ...data
      };
      localStorage.setItem('feedbackDraft', JSON.stringify(state));
      logAction("saveDraftState", "success");
    } catch (e) {
      console.warn("Could not save draft state:", e);
    }
  }

  function tryRestoreDraft() {
    try {
      const draftJson = localStorage.getItem('feedbackDraft');
      if (!draftJson) return false;
      
      const draft = JSON.parse(draftJson);
      if (!draft || !draft.recordId || draft.recordId !== currentRecordId) {
        localStorage.removeItem('feedbackDraft');
        return false;
      }
      
      // Check if draft is from current session
      const now = Date.now();
      if (now - draft.timestamp > SESSION_TIMEOUT) {
        localStorage.removeItem('feedbackDraft');
        return false;
      }
      
      // Restore selected checkboxes
      if (draft.positiveOptions && Array.isArray(draft.positiveOptions)) {
        draft.positiveOptions.forEach(option => {
          $(".positive-option").each(function() {
            if ($(this).next("label").text() === option) {
              $(this).prop("checked", true);
            }
          });
        });
      }
      if (draft.negativeOptions && Array.isArray(draft.negativeOptions)) {
        draft.negativeOptions.forEach(option => {
          $(".negative-option").each(function() {
            if ($(this).next("label").text() === option) {
              $(this).prop("checked", true);
            }
          });
        });
      }
      validateOptions();
      updateSelectionSummary();
      
      // Restore generated text
      if (draft.generatedText) {
        $("#generatedText").text(draft.generatedText);
        addCopyButton();
      }
      
      logAction("tryRestoreDraft", "success", { recordId: draft.recordId });
      return true;
    } catch (e) {
      console.warn("Could not restore draft:", e);
      return false;
    }
  }

  function saveAssignmentState(recordId) {
    try {
      const state = {
        recordId: recordId,
        timestamp: Date.now(),
        lastActivity: Date.now(),
        sessionId: SESSION_ID
      };
      localStorage.setItem('assignmentState', JSON.stringify(state));
      startAssignmentCheck();
      logAction("saveAssignmentState", "success", { recordId });
    } catch (e) {
      console.warn("Could not save assignment state:", e);
    }
  }

  function updateAssignmentActivity() {
    try {
      const stateJson = localStorage.getItem('assignmentState');
      if (!stateJson) return;
      const state = JSON.parse(stateJson);
      state.lastActivity = Date.now();
      localStorage.setItem('assignmentState', JSON.stringify(state));
      
      lastActivityTimestamp = Date.now();
      logAction("updateAssignmentActivity", "success");
    } catch (e) {
      console.warn("Could not update assignment activity:", e);
    }
  }

  function startAssignmentCheck() {
    clearInterval(assignmentCheckTimer);
    lastActivityTimestamp = Date.now();
    
    let warningShown = false;
    
    assignmentCheckTimer = setInterval(() => {
      try {
        const stateJson = localStorage.getItem('assignmentState');
        if (!stateJson) {
          clearInterval(assignmentCheckTimer);
          return;
        }
        const state = JSON.parse(stateJson);
        const now = Date.now();
        const timeSinceActivity = now - state.lastActivity;
        
        // Show warning at 9 minutes of inactivity
        if (timeSinceActivity > 9 * 60000 && !warningShown) {
          showInactivityWarning();
          warningShown = true;
        }
        
        // Auto-release at 10 minutes
        if (timeSinceActivity > ASSIGNMENT_MAX_IDLE_TIME) {
          showToast("Relace byla ukončena kvůli neaktivitě.", "error");
          markRecordAsPotentiallyOrphaned(state.recordId);
          clearInterval(assignmentCheckTimer);
          setTimeout(() => {
            window.location.reload();
          }, 2000);
        }
      } catch (e) {
        console.warn("Error in assignment check:", e);
      }
    }, 30000); // Check every 30 seconds
  }

  function startHeartbeat() {
    clearInterval(heartbeatTimer);
    
    heartbeatTimer = setInterval(() => {
      if (!currentRecordId) {
        clearInterval(heartbeatTimer);
        return;
      }
      checkRecordStatus(currentRecordId)
        .then(status => {
          if (status && status !== STATUS.ASSIGNED) {
            handleCriticalError("Tento záznam již není k dispozici", { 
              recordId: currentRecordId,
              expectedStatus: STATUS.ASSIGNED,
              actualStatus: status
            });
          }
        })
        .catch(err => {
          console.warn("Heartbeat error:", err);
        });
    }, HEARTBEAT_INTERVAL);
  }

  function setupDeadmansSwitch() {
    window.addEventListener("offline", () => {
      setTimeout(() => {
        if (!navigator.onLine && currentRecordId) {
          markRecordAsPotentiallyOrphaned(currentRecordId);
        }
      }, 60000);
    });
  }

  function markRecordAsPotentiallyOrphaned(recordId) {
    logAction("markRecordAsPotentiallyOrphaned", "info", { recordId });
    
    safeAirtableUpdate(recordId, {
      [FIELD_MAPPINGS.reviewStatus]: STATUS.UNASSIGNED,
      "Orphaned": true,
      "Last Orphaned": new Date().toISOString()
    })
    .then(() => {
      clearAssignmentState();
      logAction("markRecordAsPotentiallyOrphaned", "success", { recordId });
    })
    .catch(err => {
      console.error("Failed to mark record as orphaned:", err);
    });
  }

  function clearAssignmentState() {
    try {
      localStorage.removeItem('assignmentState');
      localStorage.removeItem('feedbackDraft');
      clearInterval(assignmentCheckTimer);
      clearInterval(heartbeatTimer);
      logAction("clearAssignmentState", "success");
    } catch (e) {
      console.warn("Could not clear assignment state:", e);
    }
  }

  function checkForOrphanedRecords() {
    try {
      const stateJson = localStorage.getItem('assignmentState');
      if (!stateJson) return;
      
      const state = JSON.parse(stateJson);
      if (!state.recordId) return;
      
      const now = Date.now();
      
      // If older than 1 hour or different session
      if (now - state.timestamp > 60 * 60 * 1000 || 
          (state.sessionId && state.sessionId !== SESSION_ID)) {
        markRecordAsPotentiallyOrphaned(state.recordId);
      }
    } catch (e) {
      console.warn("Error checking for orphaned records:", e);
    }
  }

  function startSessionTimer() {
    clearTimeout(sessionTimer);
    clearTimeout(warningTimer);
    
    warningTimer = setTimeout(() => {
      showSessionWarning();
    }, SESSION_TIMEOUT - WARNING_BEFORE_TIMEOUT);
    
    sessionTimer = setTimeout(() => {
      if (confirm("Vaše relace vypršela. Načíst stránku znovu?")) {
        if (currentRecordId) {
          markRecordAsPotentiallyOrphaned(currentRecordId)
            .finally(() => {
              window.location.reload();
            });
        } else {
          window.location.reload();
        }
      }
    }, SESSION_TIMEOUT);
  }

  function resetSessionTimer() {
    hideSessionWarning();
    startSessionTimer();
  }

  

  function showSessionWarning() {
    $("#sessionWarning").addClass("show");
  }

  function hideSessionWarning() {
    $("#sessionWarning").removeClass("show");
  }

  // Add this after the hideSessionWarning function
function showInactivityWarning() {
  showToast("Pozor: Relace bude ukončena za 1 minutu kvůli neaktivitě. Klikněte nebo stiskněte klávesu pro pokračování.", "warning", 10000);
}

  /*********************************************************
   *      User Data & Ultimate Member Integration
   *********************************************************/
// Update the getUserUltimateMetadata function
// This function properly accesses the user metadata
// Enhanced function to properly handle URLs
function getUserUltimateMetadata() {
  try {
    if (typeof window.umUserData !== 'undefined' && window.umUserData.user_login) {
      // Handle gender which could be in various formats
      let genderValue = "any";
      
      if (window.umUserData.gender) {
        // Check if it's an array like ["Muž"]
        if (Array.isArray(window.umUserData.gender)) {
          const genderText = window.umUserData.gender[0];
          if (typeof genderText === 'string') {
            if (genderText === 'Muž' || genderText.toLowerCase() === 'muž' || genderText.toLowerCase() === 'muz') {
              genderValue = 'male';
            } else if (genderText === 'Žena' || genderText.toLowerCase() === 'žena' || genderText.toLowerCase() === 'zena') {
              genderValue = 'female';
            }
          }
        }
        // Check if it's an object with "Muž" or "Žena" as keys
        else if (typeof window.umUserData.gender === 'object') {
          if ('Muž' in window.umUserData.gender) {
            genderValue = 'male';
          } else if ('Žena' in window.umUserData.gender) {
            genderValue = 'female';
          }
        } 
        // Check if it's a string
        else if (typeof window.umUserData.gender === 'string') {
          const gender = window.umUserData.gender.toLowerCase();
          if (gender === 'muž' || gender === 'muz') {
            genderValue = 'male';
          } else if (gender === 'žena' || gender === 'zena') {
            genderValue = 'female';
          } else {
            genderValue = gender;
          }
        }
      }
      
      console.log("Extracted gender value:", genderValue, "from", window.umUserData.gender);
      
      return {
        user_login: window.umUserData.user_login,
        googleUrl: window.umUserData.google_review_profile_link
          ? (window.umUserData.google_review_profile_link.match(/^https?:\/\//)
              ? window.umUserData.google_review_profile_link
              : 'https://' + window.umUserData.google_review_profile_link)
          : null,
        gender: genderValue
      };
    }
    
    console.error("User data not available in window.umUserData");
    return null; // Return null if user data is missing
  } catch (e) {
    console.error("Error getting user metadata:", e);
    return null;
  }
}

function umDebugging() {
  try {
    const debugDiv = document.getElementById("um-debugging");
    if (!debugDiv) {
      console.error("UM debugging div not found");
      return;
    }
    
    // Clear previous content
    debugDiv.innerHTML = "";
    
    // Create a heading
    const heading = document.createElement("h3");
    heading.textContent = "UM Debugging Information";
    debugDiv.appendChild(heading);
    
    // Check if umUserData exists
    if (typeof window.umUserData === 'undefined') {
      const errorMsg = document.createElement("p");
      errorMsg.textContent = "No window.umUserData found";
      errorMsg.style.color = "red";
      debugDiv.appendChild(errorMsg);
      return;
    }
    
    // Create a table to display all the values
    const table = document.createElement("table");
    table.style.width = "100%";
    table.style.borderCollapse = "collapse";
    
    // Add table header
    const thead = document.createElement("thead");
    const headerRow = document.createElement("tr");
    ["Property", "Value", "Type"].forEach(text => {
      const th = document.createElement("th");
      th.textContent = text;
      th.style.border = "1px solid #ddd";
      th.style.padding = "8px";
      th.style.textAlign = "left";
      headerRow.appendChild(th);
    });
    thead.appendChild(headerRow);
    table.appendChild(thead);
    
    // Add table body
    const tbody = document.createElement("tbody");
    for (const key in window.umUserData) {
      const row = document.createElement("tr");
      
      // Property name
      const keyCell = document.createElement("td");
      keyCell.textContent = key;
      keyCell.style.border = "1px solid #ddd";
      keyCell.style.padding = "8px";
      row.appendChild(keyCell);
      
      // Value
      const valueCell = document.createElement("td");
      const value = window.umUserData[key];
      valueCell.textContent = typeof value === 'object' ? JSON.stringify(value) : String(value);
      valueCell.style.border = "1px solid #ddd";
      valueCell.style.padding = "8px";
      row.appendChild(valueCell);
      
      // Type
      const typeCell = document.createElement("td");
      typeCell.textContent = typeof value;
      typeCell.style.border = "1px solid #ddd";
      typeCell.style.padding = "8px";
      row.appendChild(typeCell);
      
      tbody.appendChild(row);
    }
    table.appendChild(tbody);
    debugDiv.appendChild(table);
    
    // Add the processed metadata
    const metadataSection = document.createElement("div");
    metadataSection.style.marginTop = "20px";
    
    const metadataHeading = document.createElement("h4");
    metadataHeading.textContent = "Processed Metadata";
    metadataSection.appendChild(metadataHeading);
    
    const metadata = getUserUltimateMetadata();
    const metadataPre = document.createElement("pre");
    metadataPre.textContent = JSON.stringify(metadata, null, 2);
    metadataPre.style.backgroundColor = "#f5f5f5";
    metadataPre.style.padding = "10px";
    metadataPre.style.borderRadius = "4px";
    metadataSection.appendChild(metadataPre);
    
    debugDiv.appendChild(metadataSection);
    
  } catch (e) {
    console.error("Error in umDebugging function:", e);
    const debugDiv = document.getElementById("um-debugging");
    if (debugDiv) {
      debugDiv.innerHTML = `<p style="color: red">Error: ${e.message}</p>`;
    }
  }
}



// Section 2: Enforcing One Review Per Parent Order
function checkUserReviewForParentOrder(parentOrderId, userLogin) {
  return new Promise((resolve, reject) => {
    // Determine whether parentOrderId is numeric
    const isNumeric = !isNaN(parentOrderId);
    const parentOrderFilter = isNumeric
      ? `{Parent Order}=${parentOrderId}`
      : `{Parent Order}='${parentOrderId}'`;

    $.ajax({
      url: `https://api.airtable.com/v0/${airtableBaseId}/${airtableTableId}?filterByFormula=AND(${parentOrderFilter}, {Reviewer username}='${userLogin}')`,
      method: "GET",
      headers: { "Authorization": `Bearer ${airtableApiKey}` },
      success: function(response) {
        if (response.records && response.records.length > 0) {
          resolve(true);
        } else {
          resolve(false);
        }
      },
      error: function(xhr, status, error) {
        reject(new Error("Chyba při ověřování již napsaného feedbacku."));
      }
    });
  });
}








  
  

  /*********************************************************
   *     Error Handling & Logging
   *********************************************************/
  function setupErrorHandling() {
    window.onerror = function(message, source, lineno, colno, error) {
      handleError("Uncaught error", { message, source, lineno, colno, error: error?.toString() });
      return true;
    };
    window.addEventListener('unhandledrejection', function(event) {
      handleError("Unhandled promise rejection", { 
        reason: event.reason?.toString(),
        stack: event.reason?.stack
      });
    });
  }

  function logAction(action, status, data = {}) {
    const timestamp = new Date().toISOString();
    const logData = {
      timestamp,
      action,
      status,
      sessionId: SESSION_ID,
      recordId: currentRecordId,
      ...data
    };
    console.log(`[${timestamp}] ${action}: ${status}`, data);
  }

  function handleError(type, data) {
    console.error(`[ERROR] ${type}:`, data);
    logAction("error", type, data);
    showToast("Nastala neočekávaná chyba. Zkuste stránku obnovit.", "error");
    hideLoader();
  }

  function handleCriticalError(message, data) {
    console.error(`[CRITICAL ERROR] ${message}:`, data);
    logAction("criticalError", message, data);
    
    showToast(message, "error");
    hideLoader();
    
    // Release record
    if (currentRecordId) {
      safeAirtableUpdate(currentRecordId, {
        [FIELD_MAPPINGS.reviewStatus]: STATUS.UNASSIGNED,
        "Error Log": `${new Date().toISOString()}: ${message}`
      })
        .catch(e => console.error("Failed to release record after critical error:", e))
        .finally(() => {
          clearAssignmentState();
          setTimeout(() => {
            window.location.reload();
          }, 3000);
        });
    } else {
      setTimeout(() => {
        window.location.reload();
      }, 3000);
    }
  }

  /*********************************************************
   *                Utility Functions
   *********************************************************/
  function showError(msg) {
    hideLoader();
    console.error(msg);
    showToast(msg, "error");
  }
  
  function hideLoader() {
    $("#loaderContainer").hide(); 
  }
  
  function showToast(msg, type = "info", duration = 3000) {
    const t = $("#toast");
    t.text(msg).removeClass().addClass(`toast ${type} show`);
    setTimeout(() => t.removeClass("show"), duration);
  }

  function resetForm() {
    $("#generatedText").text("Vyberte možnosti výše a klikněte na 'GENEROVAT JINÝ TEXT' pro vytvoření recenze.");
    $(".positive-option, .negative-option").prop("checked", false);
    $("#publishBtn").prop("disabled", true);
    $(".selection-summary").hide();
    $(".text-area .copy-btn").remove();
  }

  function addCopyButton() {
    $(".text-area .copy-btn").remove();
    const btn = $(`
      <button class="copy-btn" aria-label="Zkopírovat text do schránky">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" 
             stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
          <path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"></path>
        </svg>
      </button>
    `);
    $(".text-area").append(btn);
    btn.on("click", function() {
      const txt = $("#generatedText").text();
      navigator.clipboard.writeText(txt)
        .then(() => {
          showToast("Text zkopírován do schránky", "success");
          btn.addClass("success-animation");
          setTimeout(() => btn.removeClass("success-animation"), 1500);
        })
        .catch((err) => {
          console.warn(err);
          showToast("Nepodařilo se zkopírovat", "error");
        });
    });
  }

  function updateSelectionSummary() {
    const selPos = [];
    $(".positive-option:checked").each(function() {
      selPos.push($(this).next("label").text());
    });
    
    const selNeg = [];
    $(".negative-option:checked").each(function() {
      selNeg.push($(this).next("label").text());
    });
    
    if (selPos.length > 0 || selNeg.length > 0) {
      $(".selection-summary").show();
      $("#positiveSummary").text(selPos.join(", "));
      
      if (selNeg.length > 0) {
        $(".negative-summary").show();
        $("#negativeSummary").text(selNeg.join(", "));
      } else {
        $(".negative-summary").hide();
      }
    } else {
      $(".selection-summary").hide();
    }
    
    // Save draft
    if (currentRecordId) {
      saveDraftState({
        positiveOptions: selPos,
        negativeOptions: selNeg
      });
    }
  }

  

})(jQuery);
